"""Domain exceptions"""


class OpenAPIParseException(Exception):
    """Exception raised when parsing OpenAPI spec fails"""

    def __init__(self, url: str, message: str):
        self.url = url
        self.message = message
        super().__init__(f"Failed to parse OpenAPI spec from '{url}': {message}")
