from dataclasses import dataclass
from typing import Any, Dict, Optional, Union
from enum import Enum


class HttpMethod(str, Enum):
    """HTTP methods supported for REST APIs"""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class GraphQLOperation(str, Enum):
    """GraphQL operation types"""
    QUERY = "QUERY"
    MUTATION = "MUTATION"
    SUBSCRIPTION = "SUBSCRIPTION"


class APIType(str, Enum):
    """API specification types"""
    OPENAPI = "openapi"
    GRAPHQL = "graphql"


@dataclass(frozen=True)
class Tool:
    """
    Domain entity representing a tool generated from an API endpoint (REST or GraphQL).
    This is the core entity in our domain.
    """
    name: str
    description: str
    input_schema: Dict[str, Any]
    metadata: 'ToolMetadata'


@dataclass(frozen=True)
class ToolMetadata:
    """Metadata about a tool needed for execution - supports REST and GraphQL"""
    api_namespace: str
    api_type: APIType
    base_url: str
    operation_id: str
    
    # REST-specific fields
    http_method: Optional[HttpMethod] = None
    path: Optional[str] = None
    request_body_schema: Optional[Dict[str, Any]] = None
    
    # GraphQL-specific fields  
    graphql_operation: Optional[GraphQLOperation] = None
    graphql_field: Optional[str] = None
    graphql_parent_type: Optional[str] = None
    graphql_field_selection: Optional[str] = None  # Fields to select in GraphQL query


@dataclass(frozen=True)
class ToolExecutionRequest:
    """Request to execute a tool"""
    tool_name: str
    input_parameters: Dict[str, Any]


@dataclass
class ToolExecutionResult:
    """Result of tool execution"""
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional['ExecutionError'] = None
    metadata: Optional['ExecutionMetadata'] = None


@dataclass
class ExecutionError:
    """Error information from tool execution"""
    type: str
    message: str
    details: Optional[Dict[str, Any]] = None


@dataclass
class ExecutionMetadata:
    """Metadata about the execution"""
    tool: str
    duration_ms: int
    status_code: int


@dataclass(frozen=True)
class OpenAPISpec:
    """Value object representing an OpenAPI specification"""
    url: str
    namespace: str
    content: Dict[str, Any]


@dataclass(frozen=True)
class GraphQLSpec:
    """Value object representing a GraphQL schema specification"""
    url: str
    namespace: str
    schema: Dict[str, Any]  # GraphQL introspection result
    endpoint_url: str       # Actual GraphQL endpoint for operations
