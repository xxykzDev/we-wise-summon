#!/usr/bin/env python3
"""
We-Wise SUMMON CLI - Unified Version
AI-powered API to MCP server generator with real OpenAPI/GraphQL parsing
"""

import asyncio
import click
import json
import os
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse
import structlog

# Import the real generator components
from infrastructure.openapi_tool_source import OpenAPIToolSource
from infrastructure.graphql_tool_source import GraphQLToolSource  
from infrastructure.api_detector import api_detector
from infrastructure.tool_registry import InMemoryToolRegistry
from application.use_cases.load_sources import LoadToolSourcesUseCase
from application.mcp_mode.generate_mcp_servers import GenerateMCPServersUseCase
from domain.entities import APIType

logger = structlog.get_logger()


@click.group()
@click.version_option(version="0.2.0")
def cli():
    """We-Wise SUMMON - AI-powered API to MCP server generator"""
    pass


@cli.command()
@click.option('--name', '-n', default='my-project', help='Project name')
def init(name: str):
    """Initialize a new SUMMON project"""
    project_dir = Path(name)
    summon_dir = project_dir / '.summon'
    
    # Create directories
    project_dir.mkdir(exist_ok=True)
    summon_dir.mkdir(exist_ok=True)
    
    # Create config file
    config = {
        "project_name": name,
        "apis": [],
        "output_dir": "./mcps",
        "version": "0.1.0"
    }
    
    config_file = summon_dir / 'config.json'
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    # Create .gitignore
    gitignore = project_dir / '.gitignore'
    with open(gitignore, 'w') as f:
        f.write("mcps/\n.summon/cache/\n__pycache__/\n*.pyc\n")
    
    click.echo(f"✅ Initialized SUMMON project: {name}")
    click.echo(f"📁 Project directory: {project_dir.absolute()}")
    click.echo(f"🔧 Config file: {config_file.absolute()}")
    click.echo(f"\n📖 Next steps:")
    click.echo(f"  cd {name}")
    click.echo(f"  summon add <api-url>")
    click.echo(f"  summon generate")


@cli.command()
@click.argument('api_url')
@click.option('--name', '-n', help='Custom name for the API')
def add(api_url: str, name: Optional[str] = None):
    """Add an API to the project with auto-detection"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    # Load config
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Advanced API type detection using the real detector
    click.echo(f"🔍 Detecting API type for: {api_url}")
    
    try:
        api_type, actual_url = asyncio.run(api_detector.detect_api_type(api_url))
        click.echo(f"✅ Detected: {api_type.value.upper()}")
        
        if actual_url != api_url:
            click.echo(f"🔗 Resolved URL: {actual_url}")
            api_url = actual_url
            
    except Exception as e:
        click.echo(f"⚠️  Detection failed: {str(e)}")
        # Fallback to simple detection
        api_type = APIType.GRAPHQL if "graphql" in api_url.lower() else APIType.OPENAPI
        click.echo(f"📝 Defaulting to: {api_type.value.upper()}")
    
    # Generate API name if not provided
    if not name:
        parsed = urlparse(api_url)
        name = parsed.netloc.replace('.', '_').replace('-', '_')
    
    # Add API to config
    api_config = {
        "name": name,
        "url": api_url,
        "type": api_type.value.upper(),
        "added_at": str(Path().cwd())
    }
    
    config['apis'].append(api_config)
    
    # Save config
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    click.echo(f"✅ Added {api_type.value.upper()} API: {name}")
    click.echo(f"🔗 URL: {api_url}")


@cli.command()
@click.option('--output', '-o', default='./mcps', help='Output directory for generated MCPs')
def generate(output: str):
    """Generate real MCP servers from added APIs using advanced parsing"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    # Load config
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    if not config['apis']:
        click.echo("❌ No APIs added. Run 'summon add <api-url>' first.")
        sys.exit(1)
    
    output_dir = Path(output)
    output_dir.mkdir(exist_ok=True)
    
    click.echo(f"🚀 Generating MCP servers with real API parsing...")
    click.echo(f"📁 Output directory: {output_dir.absolute()}")
    click.echo("")
    
    # Use the real generator
    asyncio.run(_generate_real_mcps(config['apis'], output_dir, config))


async def _generate_real_mcps(apis: list, output_dir: Path, config: dict):
    """Generate MCP servers using the real advanced parser"""
    
    # Initialize registry
    tool_registry = InMemoryToolRegistry()
    
    # Create tool sources from APIs
    sources = []
    for api_config in apis:
        click.echo(f"🔧 Processing {api_config['name']} ({api_config['type']})...")
        
        try:
            # Handle legacy REST type and map to OPENAPI
            api_type_str = api_config['type'].lower()
            if api_type_str == 'rest':
                api_type_str = 'openapi'
            api_type = APIType(api_type_str)
            namespace = api_config['name']
            url = api_config['url']
            
            # Create appropriate source
            if api_type == APIType.GRAPHQL:
                source = GraphQLToolSource(url, namespace)
            else:  # APIType.OPENAPI
                source = OpenAPIToolSource(url, namespace)
            
            sources.append(source)
            click.echo(f"   📋 Created {api_type.value} tool source")
            
        except Exception as e:
            click.echo(f"   ⚠️  Warning: {str(e)}")
            # Create fallback basic source
            from application.mcp_mode.generate_mcp_servers import MCPServerGenerator
            generator = MCPServerGenerator()
            generator._generate_basic_server(api_config['name'], api_config, output_dir)
            continue
    
    if not sources:
        click.echo("❌ No valid tool sources created")
        return
    
    # Load tools using real parsers
    click.echo(f"\n🔍 Parsing APIs and discovering tools...")
    load_sources_use_case = LoadToolSourcesUseCase(tool_registry)
    await load_sources_use_case.execute(sources)
    
    # Generate MCP servers with real tools
    click.echo(f"🏗️  Generating MCP servers...")
    # Change to output directory and generate files there
    import os
    original_cwd = os.getcwd()
    os.chdir(output_dir)
    
    try:
        generate_mcps_use_case = GenerateMCPServersUseCase(
            tool_registry=tool_registry,
            output_dir="."
        )
        
        result = await generate_mcps_use_case.execute()
    finally:
        # Always restore original working directory
        os.chdir(original_cwd)
    
    # Update result paths to be relative to original directory
    for server in result.get('servers', []):
        server['filepath'] = os.path.join(str(output_dir), server['filename'])
    
    result['output_dir'] = str(output_dir)
    result['registry_file'] = os.path.join(str(output_dir), 'registry.json')
    result['claude_config_file'] = os.path.join(str(output_dir), 'claude_desktop_config.json')
    result['agents_config_file'] = os.path.join(str(output_dir), 'agents_mcp_config.json')
    result['docker_compose_file'] = os.path.join(str(output_dir), 'docker-compose-mcps.yml')
    
    # Print results
    # Generate Docker files
    _generate_requirements_file(output_dir)
    _generate_dockerfile(output_dir)
    _generate_env_file(output_dir, result.get('servers', []))
    
    click.echo(f"\n🎉 MCP server generation complete!")
    click.echo(f"📂 Files generated in: {result['output_dir']}")
    click.echo(f"✅ Servers generated: {result['servers_generated']}")
    click.echo("")
    
    for server in result['servers']:
        click.echo(f"  📄 {server['filename']}")
        click.echo(f"     Namespace: {server['namespace']}")
        click.echo(f"     Tools: {server['tool_count']}")
        click.echo("")
    
    # Additional files
    click.echo("📋 Additional configuration files:")
    click.echo(f"  🖥️  Claude Desktop: {result['claude_config_file']}")
    click.echo(f"  🤖 Agent Framework: {result['agents_config_file']}")
    click.echo(f"  🐳 Docker Compose: {result['docker_compose_file']}")
    click.echo(f"  🐳 Dockerfile: {output_dir}/Dockerfile")
    click.echo(f"  📦 Requirements: {output_dir}/requirements.txt")
    click.echo(f"  🔧 Environment: {output_dir}/.env")
    click.echo("")
    
    click.echo("🚀 Next steps:")
    click.echo("  1. Test locally:")
    click.echo(f"     python {output_dir}/mcp_server_<namespace>.py --http 8500")
    click.echo("")
    click.echo("  2. Run with Docker:")
    click.echo(f"     docker compose up --build")
    click.echo("")
    click.echo("  3. For Claude Desktop integration:")
    click.echo(f"     Copy config from {output_dir}/claude_desktop_config.json")


async def _generate_fawkes_framework(config: dict, output_dir: Path, mcps_dir: Path, port: int):
    """Generate the complete We-Wise Fawkes agent framework"""
    
    # Create directory structure
    click.echo("🏗️  Creating directory structure...")
    _create_fawkes_directories(output_dir)
    
    # Read existing MCP configuration
    click.echo("🔍 Reading existing MCP configuration...")
    mcp_servers = _read_mcp_configuration(mcps_dir)
    
    # Generate core files
    click.echo("📄 Generating core application files...")
    _generate_fawkes_core_files(output_dir, port, mcp_servers)
    
    # Generate configuration files
    click.echo("⚙️  Generating configuration files...")
    _generate_fawkes_config_files(output_dir, mcp_servers)
    
    # Generate Docker setup with networking
    click.echo("🐳 Generating Docker setup with MCP networking...")
    _generate_fawkes_docker_setup(output_dir, mcps_dir, mcp_servers, port)
    
    # Generate environment files
    click.echo("🔧 Generating environment configuration...")
    _generate_fawkes_env_files(output_dir, mcp_servers)
    
    # Update main docker-compose to include fawkes
    click.echo("🔗 Integrating with main docker-compose...")
    _integrate_fawkes_with_main_compose(mcps_dir, output_dir, port)
    
    click.echo("")
    click.echo("🎉 We-Wise Fawkes framework generated successfully!")
    click.echo("")
    click.echo("📋 Generated files:")
    click.echo(f"  📂 Framework: {output_dir}/")
    click.echo(f"  🐳 Docker Compose: {output_dir}/docker-compose-fawkes.yml")
    click.echo(f"  🔧 Environment: {output_dir}/.env")
    click.echo(f"  ⚙️  Workers Config: {output_dir}/src/configs/workers.yaml")
    click.echo("")
    click.echo("🚀 Next steps:")
    click.echo("  1. Configure OpenAI API key:")
    click.echo(f"     echo 'OPENAI_API_KEY=your_key_here' >> {output_dir}/.env")
    click.echo("")
    click.echo("  2. Start the agent framework:")
    click.echo(f"     cd {output_dir} && docker compose -f docker-compose-fawkes.yml up --build")
    click.echo("")
    click.echo("  3. Or start everything (MCPs + Fawkes):")
    click.echo(f"     docker compose -f {mcps_dir}/docker-compose-mcps.yml -f {output_dir}/docker-compose-fawkes.yml up --build")


@cli.command()
@click.option('--port', '-p', default=8080, help='Port for web dashboard')
def dashboard(port: int):
    """Start web dashboard (coming soon)"""
    click.echo(f"🚧 Web dashboard coming soon!")
    click.echo(f"Will start on http://localhost:{port}")


@cli.command()
@click.option('--output', '-o', default='./fawkes', help='Output directory for Fawkes agent framework')
@click.option('--port', '-p', default=8210, help='Port for Fawkes API server')
def fawkes(output: str, port: int):
    """Generate We-Wise Fawkes agent framework integrated with existing MCPs"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    # Load config
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    output_dir = Path(output)
    mcps_dir = Path(config.get('output_dir', './mcps'))
    
    click.echo(f"🤖 Generating We-Wise Fawkes agent framework...")
    click.echo(f"📁 Output directory: {output_dir.absolute()}")
    click.echo(f"🔗 Integrating with MCPs in: {mcps_dir.absolute()}")
    click.echo("")
    
    # Generate the framework
    asyncio.run(_generate_fawkes_framework(config, output_dir, mcps_dir, port))


@cli.command()
def list():
    """List APIs in the current project"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    if not config['apis']:
        click.echo("📭 No APIs added yet. Run 'summon add <api-url>' to get started.")
        return
    
    click.echo(f"📋 APIs in project '{config['project_name']}':")
    for i, api in enumerate(config['apis'], 1):
        click.echo(f"  {i}. {api['name']} ({api['type']})")
        click.echo(f"     🔗 {api['url']}")


def _generate_requirements_file(output_dir: Path):
    """Generate requirements.txt file for Docker containers"""
    requirements_content = """fastmcp>=0.2.0
httpx>=0.28.1
pydantic>=2.11.0
click>=8.0.0
"""
    
    requirements_file = output_dir / "requirements.txt"
    with open(requirements_file, 'w') as f:
        f.write(requirements_content)
    
    click.echo(f"✅ Generated requirements.txt")


def _generate_dockerfile(output_dir: Path):
    """Generate Dockerfile for MCP servers"""
    dockerfile_content = """# Dockerfile for MCP Servers
# Auto-generated by we-wise-summon

FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy MCP server files
COPY . .

# Create non-root user for security
RUN useradd -m -u 1000 mcpuser && chown -R mcpuser:mcpuser /app
USER mcpuser

# Expose port for HTTP mode
EXPOSE 8500

# Default command (overridden in docker-compose for specific servers)
CMD ["python", "--version"]
"""
    
    dockerfile_path = output_dir / "Dockerfile"
    with open(dockerfile_path, 'w') as f:
        f.write(dockerfile_content)
    
    click.echo(f"✅ Generated Dockerfile")


def _generate_env_file(output_dir: Path, servers: list):
    """Generate .env file for Docker Compose using correct base URLs from servers"""
    env_content = "# Environment variables for Docker Compose\n"
    env_content += "USERNAME_PREFIX=user\n"
    
    # Add API URLs based on servers with correct base URLs
    for server in servers:
        namespace = server['namespace'].upper()
        # Use the base_url from the server (which was correctly calculated)
        base_url = server.get('base_url', '')
        if base_url:
            env_content += f"{namespace}_API_URL={base_url}\n"
    
    env_file = output_dir / ".env"
    with open(env_file, 'w') as f:
        f.write(env_content)
    
    click.echo(f"✅ Generated .env file")


def _create_fawkes_directories(output_dir: Path):
    """Create the directory structure for Fawkes framework"""
    directories = [
        output_dir,
        output_dir / "src",
        output_dir / "src" / "api",
        output_dir / "src" / "api" / "routes", 
        output_dir / "src" / "configs",
        output_dir / "src" / "core",
        output_dir / "src" / "core" / "agents",
        output_dir / "src" / "core" / "graph", 
        output_dir / "src" / "core" / "states",
        output_dir / "src" / "core" / "tools",
        output_dir / "src" / "infrastructure",
        output_dir / "src" / "utils",
    ]
    
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
        # Create __init__.py files for Python packages
        if str(directory).endswith('/src') or '/src/' in str(directory):
            init_file = directory / "__init__.py"
            if not init_file.exists():
                init_file.write_text("")


def _extract_port_from_compose(mcps_dir: Path, namespace: str):
    """Extract port for a specific MCP server from docker-compose file"""
    compose_file = mcps_dir / "docker-compose-mcps.yml"
    if not compose_file.exists():
        return 8500  # Default port
        
    with open(compose_file, 'r') as f:
        content = f.read()
    
    # Look for service and its port mapping
    import re
    service_pattern = rf'mcp-{namespace}:.*?ports:.*?"(\d+):\d+"'
    match = re.search(service_pattern, content, re.DOTALL)
    if match:
        return int(match.group(1))
    
    # Fallback: look for any port mapping in the content
    port_pattern = r'- "(\d+):\d+"'
    matches = re.findall(port_pattern, content)
    if matches:
        # Use the first port found + offset based on position
        base_port = int(matches[0])
        # Simple heuristic: add namespace hash to avoid conflicts
        offset = hash(namespace) % 100
        return base_port + offset
    
    return 8500  # Final fallback


def _read_mcp_configuration(mcps_dir: Path):
    """Read existing MCP server configuration"""
    mcp_servers = []
    
    # Read from registry.json if it exists
    registry_file = mcps_dir / "registry.json"
    if registry_file.exists():
        with open(registry_file, 'r') as f:
            registry_data = json.load(f)
            mcp_servers = registry_data.get('mcp_servers', [])
            # Convert registry format to internal format
            for server in mcp_servers:
                server['name'] = server['namespace']
                server['container_name'] = f"mcp-{server['namespace']}"
                # Try to extract port from docker-compose or use default
                port = _extract_port_from_compose(mcps_dir, server['namespace'])
                server['port'] = port
                server['url'] = f"http://{server['container_name']}:{port}"
    
    # Read from docker-compose-mcps.yml if registry doesn't exist
    elif (mcps_dir / "docker-compose-mcps.yml").exists():
        # Parse docker-compose to extract server info
        compose_file = mcps_dir / "docker-compose-mcps.yml"
        with open(compose_file, 'r') as f:
            content = f.read()
            
        # Simple parsing to extract service names and ports
        import re
        services = re.findall(r'mcp-([a-zA-Z0-9_-]+):', content)
        ports = re.findall(r'- "(\d+):\d+"', content)
        
        for i, service in enumerate(services):
            port = int(ports[i]) if i < len(ports) else 8500 + i
            mcp_servers.append({
                'name': service,
                'namespace': service,
                'port': port,
                'url': f"http://mcp-{service}:{port}",
                'container_name': f"mcp-{service}"
            })
    
    return mcp_servers


def _generate_fawkes_core_files(output_dir: Path, port: int, mcp_servers: list):
    """Generate the core Python files for Fawkes"""
    
    # Generate main.py
    main_content = f'''"""Main FastAPI application"""

import structlog
from contextlib import asynccontextmanager
from fastapi import FastAPI

from src.config import settings
from src.di import initialize_dependencies, cleanup_dependencies
from src.api.routes import agents, health

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.JSONRenderer()
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle management"""
    import sys

    print("=" * 80, file=sys.stderr)
    print("LIFESPAN: Starting Trialsai Agents", file=sys.stderr)
    print(f"LIFESPAN: Environment = {{settings.environment}}", file=sys.stderr)
    print("=" * 80, file=sys.stderr)

    logger.info("Starting Trialsai Agents", environment=settings.environment)

    try:
        print("LIFESPAN: About to initialize dependencies...", file=sys.stderr)
        await initialize_dependencies()
        print("LIFESPAN: ✓ Dependencies initialized successfully!", file=sys.stderr)
        logger.info("Dependencies initialized with dynamic workers")
    except Exception as e:
        print(f"LIFESPAN: ✗ FAILED to initialize dependencies: {{e}}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        raise

    yield

    print("LIFESPAN: Shutting down...", file=sys.stderr)
    logger.info("Shutting down")
    await cleanup_dependencies()


# Create FastAPI app
app = FastAPI(
    title="Trialsai Agents",
    description="Multi-agent system with supervisor and workers",
    version="0.1.0",
    lifespan=lifespan
)

# Include routers
app.include_router(agents.router, prefix="/agents", tags=["agents"])
app.include_router(health.router, tags=["health"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {{
        "service": "trialsai-agents",
        "version": "0.1.0",
        "status": "running",
        "mcp_servers": {len(mcp_servers)}
    }}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "src.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.environment == "development"
    )
'''

    main_file = output_dir / "src" / "main.py"
    main_file.write_text(main_content)
    
    # Generate config.py 
    config_content = f'''"""Configuration management"""

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings
from typing import Literal, Optional


class Settings(BaseSettings):
    """Application settings with validation"""

    # OpenAI Configuration
    openai_api_key: str = Field(..., description="OpenAI API key (required)")
    openai_model: str = Field(default="gpt-4o", description="OpenAI model to use")

    # Worker Configuration
    worker_max_iterations: int = Field(default=30, gt=0, description="Max iterations per worker")

    # LLM Temperature Configuration
    supervisor_temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="Temperature for supervisor")
    worker_temperature: float = Field(default=0.3, ge=0.0, le=2.0, description="Temperature for workers")

    # Graph Configuration
    recursion_limit: int = Field(default=50, gt=0, description="Max recursion depth for graph")

    # Workers Configuration File
    workers_config_path: str = Field(default="src/configs/workers.yaml", description="Path to workers config")

    # API Configuration
    port: int = Field(default={port}, gt=0, lt=65536, description="API server port")
    host: str = Field(default="0.0.0.0", description="API server host")
    log_level: Literal["debug", "info", "warning", "error", "critical"] = Field(
        default="info", description="Logging level"
    )

    # Environment
    environment: Literal["development", "staging", "production"] = Field(
        default="development", description="Application environment"
    )

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
'''

    config_file = output_dir / "src" / "config.py"
    config_file.write_text(config_content)


def _generate_fawkes_config_files(output_dir: Path, mcp_servers: list):
    """Generate configuration files for Fawkes"""
    
    # Generate workers.yaml with MCP server integration
    workers_config = {
        'supervisor': {
            'role': 'supervisor',
            'description': 'Coordinates work between specialized workers',
            'tools': ['delegate_to_worker', 'synthesize_results']
        },
        'workers': []
    }
    
    # Add a worker for each MCP server
    for server in mcp_servers:
        worker_name = f"{server['namespace']}_worker"
        workers_config['workers'].append({
            'name': worker_name,
            'role': 'specialist',
            'description': f"Specialist for {server['namespace']} API operations",
            'tools': [f"mcp_{server['namespace']}"],
            'mcp_server': {
                'name': server['namespace'],
                'url': server['url'],
                'port': server['port']
            }
        })
    
    # Add general purpose worker
    workers_config['workers'].append({
        'name': 'general_worker',
        'role': 'generalist', 
        'description': 'Handles general tasks and coordination',
        'tools': ['web_search', 'text_analysis', 'data_processing']
    })
    
    import yaml
    workers_file = output_dir / "src" / "configs" / "workers.yaml"
    with open(workers_file, 'w') as f:
        yaml.dump(workers_config, f, default_flow_style=False, indent=2)
    
    # Generate agents_mcp_config.json for MCP integration
    mcp_config = {
        'mcp_servers': {}
    }
    
    for server in mcp_servers:
        mcp_config['mcp_servers'][server['namespace']] = {
            'command': 'docker',
            'args': ['exec', server['container_name'], 'python', f"/app/mcp_server_{server['namespace']}.py"],
            'env': {
                'PYTHONPATH': '/app'
            }
        }
    
    mcp_config_file = output_dir / "agents_mcp_config.json"
    with open(mcp_config_file, 'w') as f:
        json.dump(mcp_config, f, indent=2)


def _generate_fawkes_docker_setup(output_dir: Path, mcps_dir: Path, mcp_servers: list, port: int):
    """Generate Docker setup for Fawkes with MCP networking"""
    
    # Generate requirements.txt
    requirements_content = """fastapi>=0.104.1
uvicorn[standard]>=0.24.0
pydantic>=2.5.0
pydantic-settings>=2.1.0
structlog>=23.2.0
langgraph>=0.0.70
langchain>=0.1.0
langchain-openai>=0.0.5
openai>=1.3.0
httpx>=0.25.0
pyyaml>=6.0.1
"""
    
    requirements_file = output_dir / "requirements.txt"
    requirements_file.write_text(requirements_content)
    
    # Generate Dockerfile
    dockerfile_content = """# Dockerfile for Fawkes Agent Framework
# Auto-generated by we-wise-summon

FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application files
COPY . .

# Create non-root user for security
RUN useradd -m -u 1000 fawkes && chown -R fawkes:fawkes /app
USER fawkes

# Expose port for Fawkes API
EXPOSE 8210

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=10s --retries=3 \\
    CMD curl -s http://localhost:8210/health || exit 1

# Default command
CMD ["python", "src/main.py"]
"""
    
    dockerfile_path = output_dir / "Dockerfile"
    dockerfile_path.write_text(dockerfile_content)
    
    # Generate docker-compose-fawkes.yml
    network_name = "mcps_default"  # Use the same network as MCPs
    
    compose_content = f"""# Docker Compose for Fawkes Agent Framework
# Auto-generated by we-wise-summon
# Integrates with existing MCP servers

services:
  fawkes-agents:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: fawkes-agents
    command: ["python", "src/main.py"]
    ports:
      - "{port}:{port}"
    environment:
      - OPENAI_API_KEY=${{OPENAI_API_KEY}}
      - OPENAI_MODEL=${{OPENAI_MODEL:-gpt-4o}}
      - PORT={port}
      - HOST=0.0.0.0
      - ENVIRONMENT=production
      - WORKERS_CONFIG_PATH=src/configs/workers.yaml
    volumes:
      - ./src:/app/src:ro
      - ./agents_mcp_config.json:/app/agents_mcp_config.json:ro
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-s", "http://localhost:{port}/health"]
      interval: 30s
      timeout: 3s
      retries: 3
      start_period: 15s
    depends_on:"""

    # Add dependencies on MCP servers
    for server in mcp_servers:
        compose_content += f"""
      - {server['container_name']}"""
    
    compose_content += f"""

networks:
  default:
    external: true
    name: {network_name}
"""

    compose_file = output_dir / "docker-compose-fawkes.yml"
    compose_file.write_text(compose_content)


def _generate_fawkes_env_files(output_dir: Path, mcp_servers: list):
    """Generate environment files for Fawkes"""
    
    env_content = """# Environment variables for Fawkes Agent Framework
# Auto-generated by we-wise-summon

# OpenAI Configuration (REQUIRED)
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_MODEL=gpt-4o

# Application Configuration
PORT=8210
HOST=0.0.0.0
ENVIRONMENT=development
LOG_LEVEL=info

# Worker Configuration
WORKER_MAX_ITERATIONS=30
SUPERVISOR_TEMPERATURE=0.7
WORKER_TEMPERATURE=0.3
RECURSION_LIMIT=50

# Workers Configuration File
WORKERS_CONFIG_PATH=src/configs/workers.yaml

# MCP Server Endpoints (Auto-generated from existing MCPs)
"""
    
    # Add MCP server configurations
    for server in mcp_servers:
        env_key = f"MCP_{server['namespace'].upper()}_URL"
        env_content += f"{env_key}={server['url']}\n"
    
    env_content += """
# Network Configuration
MCP_NETWORK=mcps_default
"""
    
    env_file = output_dir / ".env"
    env_file.write_text(env_content)


def _integrate_fawkes_with_main_compose(mcps_dir: Path, fawkes_dir: Path, port: int):
    """Integrate Fawkes with the main docker-compose setup"""
    
    # Create a unified docker-compose.yml that includes both MCPs and Fawkes
    unified_compose_content = f"""# Unified Docker Compose for MCPs + Fawkes Agent Framework
# Auto-generated by we-wise-summon

include:
  - {mcps_dir}/docker-compose-mcps.yml
  - {fawkes_dir}/docker-compose-fawkes.yml

# This file orchestrates both MCP servers and the Fawkes agent framework
# 
# Usage:
#   docker compose up --build
#   
# Individual services:
#   docker compose up --build mcp-*        # Start only MCP servers
#   docker compose up --build fawkes-agents # Start only Fawkes
#
# Access points:
#   - Fawkes API: http://localhost:{port}
#   - Individual MCPs: Check docker-compose-mcps.yml for ports
"""
    
    unified_file = mcps_dir.parent / "docker-compose.yml"
    unified_file.write_text(unified_compose_content)
    
    click.echo(f"✅ Created unified docker-compose.yml at {unified_file}")


if __name__ == '__main__':
    cli()