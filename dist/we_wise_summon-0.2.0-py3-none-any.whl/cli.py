#!/usr/bin/env python3
"""
We-Wise SUMMON CLI - Unified Version
AI-powered API to MCP server generator with real OpenAPI/GraphQL parsing
"""

import asyncio
import click
import json
import os
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse
import structlog

# Import the real generator components
from infrastructure.openapi_tool_source import OpenAPIToolSource
from infrastructure.graphql_tool_source import GraphQLToolSource  
from infrastructure.api_detector import api_detector
from infrastructure.tool_registry import InMemoryToolRegistry
from application.use_cases.load_sources import LoadToolSourcesUseCase
from application.mcp_mode.generate_mcp_servers import GenerateMCPServersUseCase
from domain.entities import APIType

logger = structlog.get_logger()


@click.group()
@click.version_option(version="0.2.0")
def cli():
    """We-Wise SUMMON - AI-powered API to MCP server generator"""
    pass


@cli.command()
@click.option('--name', '-n', default='my-project', help='Project name')
def init(name: str):
    """Initialize a new SUMMON project"""
    project_dir = Path(name)
    summon_dir = project_dir / '.summon'
    
    # Create directories
    project_dir.mkdir(exist_ok=True)
    summon_dir.mkdir(exist_ok=True)
    
    # Create config file
    config = {
        "project_name": name,
        "apis": [],
        "output_dir": "./mcps",
        "version": "0.1.0"
    }
    
    config_file = summon_dir / 'config.json'
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    # Create .gitignore
    gitignore = project_dir / '.gitignore'
    with open(gitignore, 'w') as f:
        f.write("mcps/\n.summon/cache/\n__pycache__/\n*.pyc\n")
    
    click.echo(f"✅ Initialized SUMMON project: {name}")
    click.echo(f"📁 Project directory: {project_dir.absolute()}")
    click.echo(f"🔧 Config file: {config_file.absolute()}")
    click.echo(f"\n📖 Next steps:")
    click.echo(f"  cd {name}")
    click.echo(f"  summon add <api-url>")
    click.echo(f"  summon generate")


@cli.command()
@click.argument('api_url')
@click.option('--name', '-n', help='Custom name for the API')
def add(api_url: str, name: Optional[str] = None):
    """Add an API to the project with auto-detection"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    # Load config
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Advanced API type detection using the real detector
    click.echo(f"🔍 Detecting API type for: {api_url}")
    
    try:
        api_type, actual_url = asyncio.run(api_detector.detect_api_type(api_url))
        click.echo(f"✅ Detected: {api_type.value.upper()}")
        
        if actual_url != api_url:
            click.echo(f"🔗 Resolved URL: {actual_url}")
            api_url = actual_url
            
    except Exception as e:
        click.echo(f"⚠️  Detection failed: {str(e)}")
        # Fallback to simple detection
        api_type = APIType.GRAPHQL if "graphql" in api_url.lower() else APIType.OPENAPI
        click.echo(f"📝 Defaulting to: {api_type.value.upper()}")
    
    # Generate API name if not provided
    if not name:
        parsed = urlparse(api_url)
        name = parsed.netloc.replace('.', '_').replace('-', '_')
    
    # Add API to config
    api_config = {
        "name": name,
        "url": api_url,
        "type": api_type.value.upper(),
        "added_at": str(Path().cwd())
    }
    
    config['apis'].append(api_config)
    
    # Save config
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    click.echo(f"✅ Added {api_type.value.upper()} API: {name}")
    click.echo(f"🔗 URL: {api_url}")


@cli.command()
@click.option('--output', '-o', default='./mcps', help='Output directory for generated MCPs')
def generate(output: str):
    """Generate real MCP servers from added APIs using advanced parsing"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    # Load config
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    if not config['apis']:
        click.echo("❌ No APIs added. Run 'summon add <api-url>' first.")
        sys.exit(1)
    
    output_dir = Path(output)
    output_dir.mkdir(exist_ok=True)
    
    click.echo(f"🚀 Generating MCP servers with real API parsing...")
    click.echo(f"📁 Output directory: {output_dir.absolute()}")
    click.echo("")
    
    # Use the real generator
    asyncio.run(_generate_real_mcps(config['apis'], output_dir, config))


async def _generate_real_mcps(apis: list, output_dir: Path, config: dict):
    """Generate MCP servers using the real advanced parser"""
    
    # Initialize registry
    tool_registry = InMemoryToolRegistry()
    
    # Create tool sources from APIs
    sources = []
    for api_config in apis:
        click.echo(f"🔧 Processing {api_config['name']} ({api_config['type']})...")
        
        try:
            # Handle legacy REST type and map to OPENAPI
            api_type_str = api_config['type'].lower()
            if api_type_str == 'rest':
                api_type_str = 'openapi'
            api_type = APIType(api_type_str)
            namespace = api_config['name']
            url = api_config['url']
            
            # Create appropriate source
            if api_type == APIType.GRAPHQL:
                source = GraphQLToolSource(url, namespace)
            else:  # APIType.OPENAPI
                source = OpenAPIToolSource(url, namespace)
            
            sources.append(source)
            click.echo(f"   📋 Created {api_type.value} tool source")
            
        except Exception as e:
            click.echo(f"   ⚠️  Warning: {str(e)}")
            # Create fallback basic source
            from application.mcp_mode.generate_mcp_servers import MCPServerGenerator
            generator = MCPServerGenerator()
            generator._generate_basic_server(api_config['name'], api_config, output_dir)
            continue
    
    if not sources:
        click.echo("❌ No valid tool sources created")
        return
    
    # Load tools using real parsers
    click.echo(f"\n🔍 Parsing APIs and discovering tools...")
    load_sources_use_case = LoadToolSourcesUseCase(tool_registry)
    await load_sources_use_case.execute(sources)
    
    # Generate MCP servers with real tools
    click.echo(f"🏗️  Generating MCP servers...")
    # Change to output directory and generate files there
    import os
    original_cwd = os.getcwd()
    os.chdir(output_dir)
    
    try:
        generate_mcps_use_case = GenerateMCPServersUseCase(
            tool_registry=tool_registry,
            output_dir="."
        )
        
        result = await generate_mcps_use_case.execute()
    finally:
        # Always restore original working directory
        os.chdir(original_cwd)
    
    # Update result paths to be relative to original directory
    for server in result.get('servers', []):
        server['filepath'] = os.path.join(str(output_dir), server['filename'])
    
    result['output_dir'] = str(output_dir)
    result['registry_file'] = os.path.join(str(output_dir), 'registry.json')
    result['claude_config_file'] = os.path.join(str(output_dir), 'claude_desktop_config.json')
    result['agents_config_file'] = os.path.join(str(output_dir), 'agents_mcp_config.json')
    result['docker_compose_file'] = os.path.join(str(output_dir), 'docker-compose-mcps.yml')
    
    # Print results
    # Generate Docker files
    _generate_requirements_file(output_dir)
    _generate_dockerfile(output_dir)
    _generate_env_file(output_dir, result.get('servers', []))
    
    click.echo(f"\n🎉 MCP server generation complete!")
    click.echo(f"📂 Files generated in: {result['output_dir']}")
    click.echo(f"✅ Servers generated: {result['servers_generated']}")
    click.echo("")
    
    for server in result['servers']:
        click.echo(f"  📄 {server['filename']}")
        click.echo(f"     Namespace: {server['namespace']}")
        click.echo(f"     Tools: {server['tool_count']}")
        click.echo("")
    
    # Additional files
    click.echo("📋 Additional configuration files:")
    click.echo(f"  🖥️  Claude Desktop: {result['claude_config_file']}")
    click.echo(f"  🤖 Agent Framework: {result['agents_config_file']}")
    click.echo(f"  🐳 Docker Compose: {result['docker_compose_file']}")
    click.echo(f"  🐳 Dockerfile: {output_dir}/Dockerfile")
    click.echo(f"  📦 Requirements: {output_dir}/requirements.txt")
    click.echo(f"  🔧 Environment: {output_dir}/.env")
    click.echo("")
    
    click.echo("🚀 Next steps:")
    click.echo("  1. Test locally:")
    click.echo(f"     python {output_dir}/mcp_server_<namespace>.py --http 8500")
    click.echo("")
    click.echo("  2. Run with Docker:")
    click.echo(f"     docker compose up --build")
    click.echo("")
    click.echo("  3. For Claude Desktop integration:")
    click.echo(f"     Copy config from {output_dir}/claude_desktop_config.json")


@cli.command()
@click.option('--port', '-p', default=8080, help='Port for web dashboard')
def dashboard(port: int):
    """Start web dashboard (coming soon)"""
    click.echo(f"🚧 Web dashboard coming soon!")
    click.echo(f"Will start on http://localhost:{port}")


@cli.command()
def list():
    """List APIs in the current project"""
    config_file = Path('.summon/config.json')
    
    if not config_file.exists():
        click.echo("❌ No SUMMON project found. Run 'summon init' first.")
        sys.exit(1)
    
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    if not config['apis']:
        click.echo("📭 No APIs added yet. Run 'summon add <api-url>' to get started.")
        return
    
    click.echo(f"📋 APIs in project '{config['project_name']}':")
    for i, api in enumerate(config['apis'], 1):
        click.echo(f"  {i}. {api['name']} ({api['type']})")
        click.echo(f"     🔗 {api['url']}")


def _generate_requirements_file(output_dir: Path):
    """Generate requirements.txt file for Docker containers"""
    requirements_content = """fastmcp>=0.2.0
httpx>=0.28.1
pydantic>=2.11.0
click>=8.0.0
"""
    
    requirements_file = output_dir / "requirements.txt"
    with open(requirements_file, 'w') as f:
        f.write(requirements_content)
    
    click.echo(f"✅ Generated requirements.txt")


def _generate_dockerfile(output_dir: Path):
    """Generate Dockerfile for MCP servers"""
    dockerfile_content = """# Dockerfile for MCP Servers
# Auto-generated by we-wise-summon

FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy MCP server files
COPY . .

# Create non-root user for security
RUN useradd -m -u 1000 mcpuser && chown -R mcpuser:mcpuser /app
USER mcpuser

# Expose port for HTTP mode
EXPOSE 8500

# Default command (overridden in docker-compose for specific servers)
CMD ["python", "--version"]
"""
    
    dockerfile_path = output_dir / "Dockerfile"
    with open(dockerfile_path, 'w') as f:
        f.write(dockerfile_content)
    
    click.echo(f"✅ Generated Dockerfile")


def _generate_env_file(output_dir: Path, servers: list):
    """Generate .env file for Docker Compose using correct base URLs from servers"""
    env_content = "# Environment variables for Docker Compose\n"
    env_content += "USERNAME_PREFIX=user\n"
    
    # Add API URLs based on servers with correct base URLs
    for server in servers:
        namespace = server['namespace'].upper()
        # Use the base_url from the server (which was correctly calculated)
        base_url = server.get('base_url', '')
        if base_url:
            env_content += f"{namespace}_API_URL={base_url}\n"
    
    env_file = output_dir / ".env"
    with open(env_file, 'w') as f:
        f.write(env_content)
    
    click.echo(f"✅ Generated .env file")


if __name__ == '__main__':
    cli()