"""In-memory tool registry implementation"""

from typing import Dict, List, Any
import structlog

from domain.entities import Tool
from application.interfaces import IToolRegistry


logger = structlog.get_logger()


class InMemoryToolRegistry(IToolRegistry):
    """In-memory storage for registered tools"""

    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def add_tool(self, tool: Tool) -> None:
        """Add a tool to the registry (implements IToolRegistry)"""
        if tool.name in self._tools:
            logger.warning("Tool already registered, overwriting", tool_name=tool.name)

        self._tools[tool.name] = tool
        logger.debug("Tool registered", tool_name=tool.name)

    def register_tool(self, tool: Tool) -> None:
        """Register a tool in the registry (alias for add_tool)"""
        self.add_tool(tool)

    def get_tool(self, tool_name: str) -> Tool:
        """Get a tool by name"""
        if tool_name not in self._tools:
            raise KeyError(f"Tool '{tool_name}' not found")

        return self._tools[tool_name]

    def get_all_tools(self) -> List[Tool]:
        """Get all registered tools (implements IToolRegistry)"""
        return list(self._tools.values())

    def list_tools(self) -> List[Tool]:
        """List all registered tools (alias for get_all_tools)"""
        return self.get_all_tools()

    def get_tools_by_namespace(self, namespace: str) -> List[Tool]:
        """Get all tools for a specific namespace (implements IToolRegistry)"""
        return [
            tool for tool in self._tools.values()
            if tool.metadata.api_namespace == namespace
        ]

    def list_tools_by_namespace(self, namespace: str) -> List[Tool]:
        """List all tools for a specific namespace (alias for get_tools_by_namespace)"""
        return self.get_tools_by_namespace(namespace)

    def get_namespaces(self) -> List[str]:
        """Get all unique namespaces (implements IToolRegistry)"""
        namespaces = set()
        for tool in self._tools.values():
            namespaces.add(tool.metadata.api_namespace)
        return sorted(list(namespaces))

    def get_stats(self) -> Dict[str, Any]:
        """Get registry statistics"""
        # Group by namespace
        namespaces = {}
        for tool in self._tools.values():
            ns = tool.metadata.api_namespace
            if ns not in namespaces:
                namespaces[ns] = 0
            namespaces[ns] += 1

        return {
            "total_tools": len(self._tools),
            "tools_by_namespace": namespaces
        }
