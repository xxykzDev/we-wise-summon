"""OpenAPI Tool Source implementation - wraps existing OpenAPI parser"""

import structlog
from typing import List

from domain.entities import Tool
from application.tool_source import IToolSource
from infrastructure.openapi_parser import OpenAPIParser


logger = structlog.get_logger()


class OpenAPIToolSource(IToolSource):
    """Tool source that parses OpenAPI specifications"""

    def __init__(self, spec_url: str, namespace: str):
        """
        Initialize OpenAPI tool source.

        Args:
            spec_url: URL to OpenAPI specification (JSON or YAML)
            namespace: Namespace prefix for tools from this source
        """
        self._spec_url = spec_url
        self._namespace = namespace
        self._parser = OpenAPIParser(timeout=30)
        self._tools_count: int = 0

    async def discover_tools(self) -> List[Tool]:
        """Discover tools from OpenAPI spec"""
        logger.info("Discovering tools from OpenAPI spec",
                   url=self._spec_url,
                   namespace=self._namespace)

        try:
            # Fetch and parse the spec
            spec = await self._parser.fetch_and_parse(self._spec_url, self._namespace)

            # Generate tools
            tools = self._parser.generate_tools(spec)

            logger.info("Discovered OpenAPI tools",
                       namespace=self._namespace,
                       tool_count=len(tools))

            self._tools_count = len(tools)
            return tools

        except Exception as e:
            logger.error("Failed to discover OpenAPI tools",
                        url=self._spec_url,
                        namespace=self._namespace,
                        error=str(e),
                        exc_info=True)
            # Don't raise - return empty list so other sources can still work
            return []

    def get_source_info(self) -> dict:
        """Get information about this OpenAPI source"""
        return {
            "type": "openapi",
            "url": self._spec_url,
            "namespace": self._namespace,
            "tools_count": self._tools_count
        }
