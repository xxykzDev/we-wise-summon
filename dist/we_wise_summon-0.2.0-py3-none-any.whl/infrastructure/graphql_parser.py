"""GraphQL introspection parser implementation"""

import httpx
import json
from typing import List, Dict, Any
import structlog

from domain.entities import Tool, ToolMetadata, GraphQLSpec, GraphQLOperation, APIType
from domain.exceptions import OpenAPIParseException
from application.interfaces import IGraphQLParser

logger = structlog.get_logger()


# GraphQL introspection query to get full schema
INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      ...FullType
    }
  }
}

fragment FullType on __Type {
  kind
  name
  description
  fields(includeDeprecated: true) {
    name
    description
    args {
      ...InputValue
    }
    type {
      ...TypeRef
    }
    isDeprecated
    deprecationReason
  }
  inputFields {
    ...InputValue
  }
  interfaces {
    ...TypeRef
  }
  enumValues(includeDeprecated: true) {
    name
    description
    isDeprecated
    deprecationReason
  }
  possibleTypes {
    ...TypeRef
  }
}

fragment InputValue on __InputValue {
  name
  description
  type {
    ...TypeRef
  }
  defaultValue
}

fragment TypeRef on __Type {
  kind
  name
  ofType {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
              }
            }
          }
        }
      }
    }
  }
}
"""


class GraphQLIntrospectionParser(IGraphQLParser):
    """Parses GraphQL schemas using introspection and generates tools"""

    def __init__(self, timeout: int = 30):
        self._timeout = timeout

    async def discover_tools(self, url: str, namespace: str) -> List[Tool]:
        """Discover tools from GraphQL endpoint (implements IToolSource interface)"""
        spec = await self.fetch_and_parse(url, namespace)
        return self.generate_tools(spec)

    async def fetch_and_parse(self, url: str, namespace: str) -> GraphQLSpec:
        """Fetch and parse a GraphQL schema via introspection"""
        try:
            # Perform introspection query
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    url,
                    json={"query": INTROSPECTION_QUERY},
                    headers={"Content-Type": "application/json"}
                )
                response.raise_for_status()
                
                result = response.json()
                
                # Check for GraphQL errors
                if "errors" in result:
                    error_messages = [error.get("message", "") for error in result["errors"]]
                    raise OpenAPIParseException(url, f"GraphQL errors: {', '.join(error_messages)}")
                
                # Validate introspection result
                if "data" not in result or "__schema" not in result["data"]:
                    raise OpenAPIParseException(url, "Invalid GraphQL introspection response")
                
                schema_data = result["data"]["__schema"]
                
                return GraphQLSpec(
                    url=url,
                    namespace=namespace,
                    schema=schema_data,
                    endpoint_url=url
                )

        except httpx.HTTPError as e:
            raise OpenAPIParseException(url, f"HTTP error during GraphQL introspection: {str(e)}")
        except Exception as e:
            raise OpenAPIParseException(url, f"GraphQL introspection error: {str(e)}")

    def generate_tools(self, spec: GraphQLSpec) -> List[Tool]:
        """Generate tools from a GraphQL schema"""
        tools = []
        schema = spec.schema
        namespace = spec.namespace

        # Get root operation types
        query_type = schema.get("queryType", {}).get("name", "Query")
        mutation_type_info = schema.get("mutationType")
        subscription_type_info = schema.get("subscriptionType")
        mutation_type = mutation_type_info.get("name") if mutation_type_info else None
        subscription_type = subscription_type_info.get("name") if subscription_type_info else None

        # Process all types
        types = schema.get("types", [])
        
        for type_info in types:
            type_name = type_info.get("name", "")
            type_kind = type_info.get("kind", "")
            fields = type_info.get("fields", [])
            
            # Skip introspection types
            if type_name.startswith("__"):
                continue
            
            # Process only OBJECT types that are root operation types
            if type_kind == "OBJECT" and fields:
                
                # Determine operation type
                operation_type = None
                if type_name == query_type:
                    operation_type = GraphQLOperation.QUERY
                elif type_name == mutation_type:
                    operation_type = GraphQLOperation.MUTATION
                elif type_name == subscription_type:
                    operation_type = GraphQLOperation.SUBSCRIPTION
                else:
                    # Skip non-root types for now
                    continue
                
                # Generate tools for each field
                for field in fields:
                    tool = self._create_tool_from_field(
                        namespace=namespace,
                        type_name=type_name,
                        operation_type=operation_type,
                        field=field,
                        endpoint_url=spec.endpoint_url,
                        all_types=types
                    )
                    
                    if tool:
                        tools.append(tool)

        logger.info("Generated GraphQL tools", 
                   namespace=namespace, 
                   tool_count=len(tools),
                   endpoint=spec.endpoint_url)

        return tools

    def _create_tool_from_field(
        self,
        namespace: str,
        type_name: str,
        operation_type: GraphQLOperation,
        field: Dict[str, Any],
        endpoint_url: str,
        all_types: List[Dict[str, Any]]
    ) -> Tool:
        """Create a Tool from a GraphQL field"""
        
        field_name = field.get("name", "")
        field_description = field.get("description") or f"{operation_type.value.title()}: {field_name}"
        field_args = field.get("args", [])
        
        # Generate tool name
        tool_name = f"{namespace}_{operation_type.value.lower()}_{field_name}"
        
        # Build input schema from field arguments
        input_schema = self._build_input_schema_from_args(field_args, all_types)
        
        # Generate field selection for GraphQL query
        field_selection = self._build_field_selection(field, all_types)
        
        # Create metadata
        metadata = ToolMetadata(
            api_namespace=namespace,
            api_type=APIType.GRAPHQL,
            base_url=endpoint_url,
            operation_id=f"{type_name}.{field_name}",
            # GraphQL-specific fields
            graphql_operation=operation_type,
            graphql_field=field_name,
            graphql_parent_type=type_name,
            graphql_field_selection=field_selection
        )
        
        return Tool(
            name=tool_name,
            description=field_description,
            input_schema=input_schema,
            metadata=metadata
        )

    def _build_input_schema_from_args(self, args: List[Dict[str, Any]], all_types: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Build JSON Schema for tool input from GraphQL field arguments"""
        schema = {
            "type": "object",
            "properties": {},
            "required": []
        }
        
        for arg in args:
            arg_name = arg.get("name", "")
            arg_type_info = arg.get("type", {})
            arg_description = arg.get("description", "")
            
            # Parse GraphQL type to JSON Schema
            json_type, is_required = self._graphql_type_to_json_schema(arg_type_info, all_types)
            
            # Add to properties
            schema["properties"][arg_name] = {
                **json_type,
                "description": arg_description
            }
            
            # Add to required if needed
            if is_required:
                schema["required"].append(arg_name)
        
        return schema

    def _graphql_type_to_json_schema(self, type_info: Dict[str, Any], all_types: List[Dict[str, Any]]) -> tuple[Dict[str, Any], bool]:
        """Convert GraphQL type to JSON Schema type"""
        
        kind = type_info.get("kind", "")
        name = type_info.get("name")
        of_type = type_info.get("ofType")
        
        # Handle NON_NULL wrapper
        if kind == "NON_NULL":
            if of_type:
                inner_type, _ = self._graphql_type_to_json_schema(of_type, all_types)
                return inner_type, True  # Required
            return {"type": "string"}, True
        
        # Handle LIST wrapper
        if kind == "LIST":
            if of_type:
                item_type, _ = self._graphql_type_to_json_schema(of_type, all_types)
                return {
                    "type": "array",
                    "items": item_type
                }, False
            return {"type": "array"}, False
        
        # Handle scalar types
        if kind == "SCALAR":
            scalar_map = {
                "String": {"type": "string"},
                "Int": {"type": "integer"},
                "Float": {"type": "number"},
                "Boolean": {"type": "boolean"},
                "ID": {"type": "string"}
            }
            return scalar_map.get(name, {"type": "string"}), False
        
        # Handle enums
        if kind == "ENUM":
            # Find enum values
            enum_type = next((t for t in all_types if t.get("name") == name), None)
            if enum_type:
                enum_values = [v.get("name") for v in enum_type.get("enumValues", [])]
                return {
                    "type": "string",
                    "enum": enum_values
                }, False
            return {"type": "string"}, False
        
        # Handle input objects and other complex types
        if kind in ["INPUT_OBJECT", "OBJECT", "INTERFACE"]:
            return {"type": "object"}, False
        
        # Default fallback
        return {"type": "string"}, False

    def _build_field_selection(self, field: Dict[str, Any], all_types: List[Dict[str, Any]]) -> str:
        """Build field selection string for GraphQL query based on return type"""
        field_type = field.get("type", {})
        return self._build_field_selection_from_type(field_type, all_types, depth=0)
    
    def _build_field_selection_from_type(self, field_type: Dict[str, Any], all_types: List[Dict[str, Any]], depth: int = 0) -> str:
        """Recursively build field selection from GraphQL type"""
        if depth > 3:  # Prevent infinite recursion
            return ""
            
        kind = field_type.get("kind", "")
        type_name = field_type.get("name")
        of_type = field_type.get("ofType")
        
        # Handle NON_NULL wrapper
        if kind == "NON_NULL" and of_type:
            return self._build_field_selection_from_type(of_type, all_types, depth)
            
        # Handle LIST wrapper  
        if kind == "LIST" and of_type:
            return self._build_field_selection_from_type(of_type, all_types, depth)
        
        # Handle scalar types - no field selection needed
        if kind == "SCALAR":
            return ""
            
        # Handle enum types - no field selection needed
        if kind == "ENUM":
            return ""
            
        # Handle object/interface types - need field selection
        if kind in ["OBJECT", "INTERFACE"] and type_name:
            return self._build_object_field_selection(type_name, all_types, depth + 1)
            
        return ""
    
    def _build_object_field_selection(self, type_name: str, all_types: List[Dict[str, Any]], depth: int) -> str:
        """Build field selection for object types"""
        # Find the type definition
        type_def = next((t for t in all_types if t.get("name") == type_name), None)
        if not type_def:
            return ""
            
        fields = type_def.get("fields", [])
        if not fields:
            return ""
        
        # Get scalar and enum fields (basic types we can select)
        selectable_fields = []
        
        for field in fields:
            field_name = field.get("name", "")
            if not field_name or field_name.startswith("__"):
                continue
                
            field_type = field.get("type", {})
            field_kind = self._get_base_type_kind(field_type)
            
            # Include scalar and enum fields
            if field_kind in ["SCALAR", "ENUM"]:
                selectable_fields.append(field_name)
            # For objects, include them but limit depth to prevent cycles
            elif field_kind in ["OBJECT", "INTERFACE"] and depth < 2:
                nested_selection = self._build_field_selection_from_type(field_type, all_types, depth + 1)
                if nested_selection:
                    # Add proper braces for nested field selection
                    selectable_fields.append(f"{field_name} {{ {nested_selection} }}")
                else:
                    # If we can't get nested fields, just include the field name for basic info
                    selectable_fields.append(field_name)
        
        return " ".join(selectable_fields[:10])  # Limit to first 10 fields to avoid too complex queries
    
    def _get_base_type_kind(self, field_type: Dict[str, Any]) -> str:
        """Get the base kind of a type, unwrapping NON_NULL and LIST wrappers"""
        kind = field_type.get("kind", "")
        
        if kind in ["NON_NULL", "LIST"]:
            of_type = field_type.get("ofType")
            if of_type:
                return self._get_base_type_kind(of_type)
                
        return kind