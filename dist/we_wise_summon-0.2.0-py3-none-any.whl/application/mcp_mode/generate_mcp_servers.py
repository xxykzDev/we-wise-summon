"""Use Case: Generate MCP Servers from discovered OpenAPI specs"""

import os
import json
import structlog
from pathlib import Path
from typing import List, Dict, Any
from application.interfaces import IToolRegistry
from application.mcp_mode.fastmcp_template import generate_fastmcp_server_code
from config import settings
from templates import render_template_to_file, render_template

logger = structlog.get_logger()


class GenerateMCPServersUseCase:
    """
    Generates standalone MCP server files for each namespace in the registry.

    Each MCP server is a complete, runnable Python file that:
    - Implements the MCP protocol using the official Python SDK
    - Contains all tools from a specific namespace
    - Can be executed independently via stdio
    - Has no dependencies on this hub
    """

    def __init__(
        self,
        tool_registry: IToolRegistry,
        output_dir: str = "mcp_output"
    ):
        self.tool_registry = tool_registry
        self.output_dir = Path(output_dir)

    async def execute(self) -> Dict[str, Any]:
        """
        Generate MCP servers for all namespaces in the registry.

        Returns:
            Dict with generation results and metadata
        """
        logger.info("Starting MCP server generation", output_dir=str(self.output_dir))

        # Ensure output directory exists
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Get all tools from registry
        all_tools = self.tool_registry.list_tools()

        # Group tools by namespace
        tools_by_namespace = self._group_by_namespace(all_tools)

        logger.info(
            "Grouped tools by namespace",
            namespace_count=len(tools_by_namespace),
            namespaces=list(tools_by_namespace.keys())
        )

        # Generate MCP server for each namespace
        generated_servers = []
        for namespace, tools in tools_by_namespace.items():
            server_info = await self._generate_server(namespace, tools)
            generated_servers.append(server_info)

        # Generate registry file
        registry_file = self._generate_registry(generated_servers)

        # Generate Claude Desktop config
        claude_config_file = self._generate_claude_config(generated_servers)

        # Generate agents framework config (HTTP/SSE)
        agents_config_file = self._generate_agents_config(generated_servers)

        # Generate docker-compose for HTTP/SSE mode
        docker_compose_file = self._generate_docker_compose(generated_servers)

        logger.info(
            "MCP server generation completed",
            servers_generated=len(generated_servers),
            registry_file=registry_file,
            claude_config_file=claude_config_file,
            agents_config_file=agents_config_file,
            docker_compose_file=docker_compose_file
        )

        return {
            "success": True,
            "servers_generated": len(generated_servers),
            "output_dir": str(self.output_dir),
            "servers": generated_servers,
            "registry_file": registry_file,
            "claude_config_file": claude_config_file,
            "agents_config_file": agents_config_file,
            "docker_compose_file": docker_compose_file
        }

    def _group_by_namespace(self, tools) -> Dict[str, List]:
        """Group tools by their namespace"""
        grouped = {}
        for tool in tools:
            namespace = tool.metadata.api_namespace
            if namespace not in grouped:
                grouped[namespace] = []
            grouped[namespace].append(tool)
        return grouped

    async def _generate_server(self, namespace: str, tools: List) -> Dict[str, Any]:
        """Generate a single MCP server file for a namespace"""

        logger.info(
            "Generating MCP server",
            namespace=namespace,
            tool_count=len(tools)
        )

        # Generate description
        description = f"MCP Server for {namespace} API\nProvides {len(tools)} tools"

        # Generate server code using FastMCP template
        logger.info("Using FastMCP template", namespace=namespace)
        server_code = generate_fastmcp_server_code(
            namespace=namespace,
            tools=tools,
            description=description
        )

        # Write to file
        filename = f"mcp_server_{namespace}.py"
        filepath = self.output_dir / filename

        with open(filepath, "w") as f:
            f.write(server_code)

        # Make executable
        os.chmod(filepath, 0o755)

        logger.info(
            "MCP server generated",
            namespace=namespace,
            filepath=str(filepath),
            tool_count=len(tools)
        )

        # Extract base_url from tools (they all should have the same base_url)
        base_url = tools[0].metadata.base_url if tools else ""

        return {
            "namespace": namespace,
            "filename": filename,
            "filepath": str(filepath),
            "tool_count": len(tools),
            "tools": [tool.name for tool in tools],
            "base_url": base_url
        }

    def _generate_registry(self, servers: List[Dict[str, Any]]) -> str:
        """Generate a registry JSON file with all MCP servers"""

        registry = {
            "version": "1.0",
            "generated_at": "auto-generated",
            "mcp_servers": []
        }

        for server in servers:
            registry["mcp_servers"].append({
                "namespace": server["namespace"],
                "filename": server["filename"],
                "filepath": server["filepath"],
                "tool_count": server["tool_count"],
                "tools": server["tools"]
            })

        registry_file = self.output_dir / "registry.json"

        with open(registry_file, "w") as f:
            json.dump(registry, f, indent=2)

        logger.info("Registry file generated", filepath=str(registry_file))

        return str(registry_file)

    def _generate_claude_config(self, servers: List[Dict[str, Any]]) -> str:
        """Generate Claude Desktop configuration file"""

        # Prepare template data
        servers_data = []
        for server in servers:
            servers_data.append({
                'namespace': server['namespace'],
                'absolute_path': os.path.abspath(server['filepath'])
            })

        config_file = self.output_dir / "claude_desktop_config.json"
        
        # Use Jinja2 template
        render_template_to_file(
            'configs/claude_desktop.json.j2',
            {'servers': servers_data},
            str(config_file)
        )

        logger.info("Claude Desktop config generated", filepath=str(config_file))

        return str(config_file)

    def _generate_agents_config(self, servers: List[Dict[str, Any]]) -> str:
        """Generate agents framework configuration file (HTTP/SSE mode)"""

        base_port = settings.mcp_base_port

        # Prepare template data
        servers_data = []
        for i, server in enumerate(servers):
            port = base_port + i
            servers_data.append({
                'namespace': server['namespace'],
                'port': port,
                'tool_count': server['tool_count'],
                'tools': server['tools']
            })

        config_file = self.output_dir / "agents_mcp_config.json"
        
        # Use Jinja2 template
        render_template_to_file(
            'configs/agents_mcp.json.j2',
            {
                'servers': servers_data,
                'base_port': base_port
            },
            str(config_file)
        )

        logger.info("Agents framework config generated", filepath=str(config_file))

        return str(config_file)

    def _generate_docker_compose(self, servers: List[Dict[str, Any]]) -> str:
        """Generate docker-compose.yml for running MCPs in HTTP/SSE mode"""

        base_port = settings.mcp_base_port

        # Prepare template data
        servers_data = []
        for i, server in enumerate(servers):
            port = base_port + i
            service_name = f"mcp-{server['namespace']}"
            namespace = server['namespace']
            api_url_var = f"{namespace.upper()}_API_URL"

            servers_data.append({
                'service_name': service_name,
                'namespace': namespace,
                'filename': server['filename'],
                'port': port,
                'api_url_var': api_url_var
            })

        compose_file = self.output_dir / "docker-compose-mcps.yml"
        
        # Use Jinja2 template
        render_template_to_file(
            'docker/docker-compose.yml.j2',
            {'servers': servers_data},
            str(compose_file)
        )

        logger.info("Docker Compose file generated", filepath=str(compose_file))

        return str(compose_file)


class MCPServerGenerator:
    """
    Simplified MCP server generator for CLI usage.
    Wraps the GenerateMCPServersUseCase for easy CLI integration.
    """
    
    def __init__(self):
        pass
    
    def generate_servers(self, tool_sources, output_dir: str = "./mcps"):
        """
        Generate MCP servers from tool sources.
        
        Args:
            tool_sources: List of ToolSource objects (OpenAPIToolSource, GraphQLToolSource)
            output_dir: Output directory for generated servers
        """
        from pathlib import Path
        import asyncio
        from application.mcp_mode.fastmcp_template import generate_fastmcp_server_code
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        for tool_source in tool_sources:
            try:
                # Load tools from the source
                tools = asyncio.run(tool_source.load_tools())
                
                if not tools:
                    # If no tools loaded, create a basic server with connection test
                    namespace = self._get_namespace_from_source(tool_source)
                    self._generate_basic_server(namespace, tool_source, output_path)
                else:
                    # Use full tool-based generation
                    namespace = tools[0].metadata.api_namespace
                    description = f"MCP Server for {namespace} API\nProvides {len(tools)} tools"
                    
                    server_code = generate_fastmcp_server_code(
                        namespace=namespace,
                        tools=tools,
                        description=description
                    )
                    
                    filename = f"mcp_server_{namespace}.py"
                    filepath = output_path / filename
                    
                    with open(filepath, "w") as f:
                        f.write(server_code)
                    
                    # Make executable
                    import os
                    os.chmod(filepath, 0o755)
                    
                    print(f"✅ Generated MCP server: {filename}")
                    
            except Exception as e:
                namespace = self._get_namespace_from_source(tool_source)
                print(f"⚠️  Could not parse {namespace} API, generating basic server: {str(e)}")
                self._generate_basic_server(namespace, tool_source, output_path)
    
    def _get_namespace_from_source(self, tool_source) -> str:
        """Extract namespace from tool source URL"""
        url = getattr(tool_source, 'base_url', 'unknown')
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.netloc.replace('.', '_').replace('-', '_')
    
    def _generate_basic_server(self, namespace: str, tool_source, output_path):
        """Generate a basic server when API parsing fails"""
        from application.mcp_mode.fastmcp_template import generate_fastmcp_server_code
        
        # Create a minimal tool list for basic functionality
        from domain.entities import Tool, ToolMetadata, APIType
        
        api_type = APIType.OPENAPI
        if hasattr(tool_source, 'base_url') and 'graphql' in getattr(tool_source, 'base_url', ''):
            api_type = APIType.GRAPHQL
        
        test_tool = Tool(
            name=f"test_connection",
            description=f"Test connection to {namespace} API",
            input_schema={"type": "object", "properties": {}},
            metadata=ToolMetadata(
                api_namespace=namespace,
                api_type=api_type,
                base_url=getattr(tool_source, 'base_url', 'http://localhost'),
                operation_id="test_connection"
            )
        )
        
        # Generate server with basic tool
        server_code = generate_fastmcp_server_code(
            namespace=namespace,
            tools=[test_tool],
            description=f"Basic MCP Server for {namespace}\nNote: This is a basic version. Full API parsing coming soon!"
        )
        
        filename = f"mcp_server_{namespace}.py"
        filepath = output_path / filename
        
        with open(filepath, "w") as f:
            f.write(server_code)
        
        # Make executable
        import os
        os.chmod(filepath, 0o755)
        
        print(f"✅ Generated MCP server: {filename}")
