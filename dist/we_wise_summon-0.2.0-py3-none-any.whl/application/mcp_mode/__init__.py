"""MCP Mode - Generate standalone MCP servers from OpenAPI specs"""
