"""Application interfaces for dependency inversion"""

from abc import ABC, abstractmethod
from typing import List, Optional
from domain.entities import Tool


class IToolRegistry(ABC):
    """Interface for tool registry"""

    @abstractmethod
    def add_tool(self, tool: Tool) -> None:
        """Add a tool to the registry"""
        pass

    @abstractmethod
    def get_tool(self, tool_name: str) -> Optional[Tool]:
        """Get a tool by name"""
        pass

    @abstractmethod
    def get_tools_by_namespace(self, namespace: str) -> List[Tool]:
        """Get all tools for a namespace"""
        pass

    @abstractmethod
    def get_all_tools(self) -> List[Tool]:
        """Get all tools"""
        pass

    @abstractmethod
    def get_namespaces(self) -> List[str]:
        """Get all unique namespaces"""
        pass


class IOpenAPIParser(ABC):
    """Interface for OpenAPI parser"""

    @abstractmethod
    async def discover_tools(self, url: str, namespace: str) -> List[Tool]:
        """Discover tools from OpenAPI specification"""
        pass


class IGraphQLParser(ABC):
    """Interface for GraphQL parser"""

    @abstractmethod
    async def discover_tools(self, url: str, namespace: str) -> List[Tool]:
        """Discover tools from GraphQL endpoint via introspection"""
        pass
