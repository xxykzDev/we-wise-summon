"""Use case for loading tools from multiple sources (OpenAPI + MCP)"""

from typing import List
import structlog

from application.tool_source import IToolSource
from application.interfaces import IToolRegistry


logger = structlog.get_logger()


class LoadToolSourcesUseCase:
    """Loads tools from multiple sources (OpenAPI, MCP, etc.)"""

    def __init__(self, registry: IToolRegistry):
        self._registry = registry

    async def execute(self, sources: List[IToolSource]) -> None:
        """
        Load tools from all sources and register them.

        Args:
            sources: List of tool sources to load from
        """
        total_tools = 0

        for source in sources:
            try:
                source_info = source.get_source_info()
                logger.info("Loading tools from source",
                          source_type=source_info["type"],
                          namespace=source_info["namespace"],
                          url=source_info["url"])

                # Discover tools from this source
                tools = await source.discover_tools()

                if not tools:
                    logger.warning("No tools discovered from source",
                                 source_type=source_info["type"],
                                 namespace=source_info["namespace"])
                    continue

                # Register each tool
                for tool in tools:
                    self._registry.register_tool(tool)
                    logger.debug("Registered tool",
                               tool_name=tool.name,
                               namespace=source_info["namespace"])

                logger.info("Successfully loaded tools from source",
                          source_type=source_info["type"],
                          namespace=source_info["namespace"],
                          tools_count=len(tools))

                total_tools += len(tools)

            except Exception as e:
                source_info = source.get_source_info()
                logger.error("Failed to load tools from source",
                           source_type=source_info.get("type", "unknown"),
                           namespace=source_info.get("namespace", "unknown"),
                           error=str(e),
                           exc_info=True)
                # Continue with other sources even if one fails
                continue

        logger.info("Tool loading complete", total_tools=total_tools)
