"""
Jinja2 Templates for Summon Code Generation

This module provides a centralized template system using Jinja2 for generating:
- MCP server code (OpenAPI and GraphQL)  
- Docker configurations (Dockerfile, docker-compose)
- Configuration files (Claude Desktop, agents framework)
- Environment files

Templates are organized by category:
- mcp/: MCP server code templates
- docker/: Docker-related templates  
- configs/: Configuration file templates
- environments/: Environment and deployment templates
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional
from jinja2 import Environment, FileSystemLoader, select_autoescape

# Get the templates directory path
TEMPLATES_DIR = Path(__file__).parent

class TemplateEngine:
    """Centralized template engine for all Summon code generation"""
    
    def __init__(self):
        """Initialize Jinja2 environment with proper configuration"""
        self.env = Environment(
            loader=FileSystemLoader(TEMPLATES_DIR),
            autoescape=select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True
        )
        
        # Add custom filters
        self.env.filters['snake_case'] = self._snake_case_filter
        self.env.filters['sanitize_name'] = self._sanitize_name_filter
    
    def render(self, template_name: str, context: Dict[str, Any]) -> str:
        """
        Render a template with the given context
        
        Args:
            template_name: Template file path (e.g., 'mcp/server_openapi.py.j2')
            context: Template variables
            
        Returns:
            Rendered template content
        """
        template = self.env.get_template(template_name)
        return template.render(**context)
    
    def render_to_file(
        self, 
        template_name: str, 
        context: Dict[str, Any], 
        output_path: str
    ) -> None:
        """
        Render template and write to file
        
        Args:
            template_name: Template file path
            context: Template variables
            output_path: Output file path
        """
        content = self.render(template_name, context)
        
        # Ensure output directory exists
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Write content to file
        output_file.write_text(content, encoding='utf-8')
    
    def _snake_case_filter(self, value: str) -> str:
        """Convert string to snake_case"""
        import re
        # Convert camelCase/PascalCase to snake_case
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', value)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()
    
    def _sanitize_name_filter(self, value: str) -> str:
        """Sanitize name for Python identifiers"""
        import re
        # Replace invalid characters
        sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', value)
        
        # Ensure doesn't start with digit
        if sanitized and sanitized[0].isdigit():
            sanitized = f"_{sanitized}"
            
        return sanitized


# Global template engine instance
template_engine = TemplateEngine()

def render_template(template_name: str, context: Dict[str, Any]) -> str:
    """Convenience function for rendering templates"""
    return template_engine.render(template_name, context)

def render_template_to_file(
    template_name: str, 
    context: Dict[str, Any], 
    output_path: str
) -> None:
    """Convenience function for rendering templates to files"""
    template_engine.render_to_file(template_name, context, output_path)