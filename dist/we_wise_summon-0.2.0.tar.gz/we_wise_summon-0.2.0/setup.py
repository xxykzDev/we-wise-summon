from setuptools import setup, find_packages

setup(
    name="we-wise-summon",
    version="0.2.0",
    description="Unified CLI + Advanced MCP Generator: Real OpenAPI/GraphQL parsing with production-ready MCP servers",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="We-Wise",
    author_email="contact@we-wise.ai",
    url="https://github.com/we-wise/summon",
    packages=find_packages("src"),
    package_dir={"": "src"},
    py_modules=["cli", "config"],  # Include standalone modules
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0.0",
        "pydantic>=2.11.0",
        "pydantic-settings>=2.6.1",
        "httpx>=0.28.1",
        "openapi-spec-validator==0.7.1",
        "pyyaml==6.0.2",
        "jsonschema==4.23.0",
        "structlog==24.4.0",
        "fastmcp>=0.2.0",  # For MCP server generation
    ],
    entry_points={
        "console_scripts": [
            "summon=cli:cli",  # CLI module from package root
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="api mcp claude ai automation",
)