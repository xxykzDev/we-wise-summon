"""Tool Source abstraction - supports multiple protocols"""

from abc import ABC, abstractmethod
from typing import List
from domain.entities import Tool


class IToolSource(ABC):
    """
    Abstract interface for tool sources.

    A tool source can discover tools from different protocols:
    - OpenAPI specifications
    - MCP (Model Context Protocol) servers (future)
    - GraphQL schemas (future)
    """

    @abstractmethod
    async def discover_tools(self) -> List[Tool]:
        """
        Discover all available tools from this source.

        Returns:
            List of Tool entities

        Raises:
            Exception if discovery fails
        """
        pass

    @abstractmethod
    def get_source_info(self) -> dict:
        """
        Get information about this source.

        Returns:
            Dict with source type, URL, namespace, etc.
        """
        pass
