"""FastMCP Server Code Generator - Modern MCP server generation using FastMCP"""

import json
from typing import List, Dict, Any
from domain.entities import Tool, APIType, GraphQLOperation
from config import settings


def generate_fastmcp_server_code(
    namespace: str,
    tools: List[Tool],
    description: str = ""
) -> str:
    """
    Generate a standalone FastMCP server Python file for a given namespace.

    This uses the modern FastMCP API which is much simpler:
    - No manual list_tools() implementation
    - No manual call_tool() routing
    - Each tool is a simple @mcp.tool() decorated function
    - Automatic parameter extraction from function signature
    - Much less boilerplate code

    Args:
        namespace: The API namespace (e.g., "suggestions", "clinicaltrials")
        tools: List of Tool entities from domain layer
        description: Optional description of this MCP server

    Returns:
        Complete Python code as string for the FastMCP server
    """

    # Extract unique base URL and detect API types
    base_url = tools[0].metadata.base_url if tools else "http://localhost"
    
    # Detect API types in this namespace
    api_types = set()
    for tool in tools:
        api_types.add(tool.metadata.api_type)
    
    api_type_str = " + ".join([t.value.upper() for t in sorted(api_types)])
    if not api_type_str:
        api_type_str = "API"

    # Generate tool functions 
    tool_functions = []
    for tool in tools:
        func_code = _generate_single_tool_function(tool, namespace)
        tool_functions.append(func_code)

    # Generate imports (extract all used types)
    used_types = _extract_used_types(tools)
    type_imports = _generate_type_imports(used_types)

    # Generate the complete server code using string template
    server_code = f'''#!/usr/bin/env python3
"""
Auto-generated FastMCP server for {namespace}
{description}

Generated using we-wise-summon - {api_type_str} endpoint integration
"""

import asyncio
import httpx
from typing import Any{type_imports}
from fastmcp import FastMCP

# Configuration
NAMESPACE = "{namespace}"
BASE_URL = "{base_url}"
TIMEOUT = httpx.Timeout(30.0)  # 30 second timeout

# Initialize FastMCP
mcp = FastMCP("{namespace.replace('_', ' ').title()} Server")

{chr(10).join(tool_functions)}

if __name__ == "__main__":
    import sys
    if "--http" in sys.argv:
        port_idx = sys.argv.index("--http") + 1
        port = int(sys.argv[port_idx]) if port_idx < len(sys.argv) else {settings.mcp_default_port}
        mcp.run(transport="streamable-http", host="0.0.0.0", port=port)
    else:
        mcp.run(transport="stdio")
'''
    return server_code


def _prepare_tool_template_data(tool: Tool, namespace: str) -> Dict[str, Any]:
    """Prepare template data for a single tool"""
    
    # Extract function name (clean, without namespace prefix)
    func_name = _get_function_name(tool, namespace)

    # Extract parameters from schema
    params = _extract_parameters(tool.input_schema)

    # Check if needs multiline signature
    multiline_signature = len(params) > 2 or sum(len(p.get("sanitized_name", p["name"])) + len(p["type"]) for p in params) > 60

    # Build request code (REST or GraphQL)
    if tool.metadata.api_type == APIType.GRAPHQL:
        request_code = _build_graphql_request_code(tool, params)
    else:
        request_code = _build_rest_request_code(tool, params)

    # Build return code
    return_code = _build_return_code(tool.metadata.api_type)

    return {
        'tool': tool,
        'function_name': func_name,
        'parameters': params,
        'multiline_signature': multiline_signature,
        'graphql_request_code': request_code if tool.metadata.api_type == APIType.GRAPHQL else '',
        'rest_request_code': request_code if tool.metadata.api_type != APIType.GRAPHQL else '',
        'return_code': return_code
    }


def _generate_tool_functions(tools: List[Tool], namespace: str) -> str:
    """Generate @mcp.tool() decorated functions for each tool"""
    functions = []

    for tool in tools:
        func = _generate_single_tool_function(tool, namespace)
        functions.append(func)

    return "\n\n".join(functions)


def _generate_single_tool_function(tool: Tool, namespace: str) -> str:
    """Generate a single @mcp.tool() decorated function using string templates"""
    
    # Extract function name (clean, without namespace prefix)
    func_name = _get_function_name(tool, namespace)
    
    # Extract parameters from schema
    params = _extract_parameters(tool.input_schema)
    
    # Build function signature
    signature = _build_function_signature(func_name, params)
    
    # Build docstring
    docstring = _build_docstring(tool, params)
    
    # Build request code (REST or GraphQL)
    request_code = _build_request_code(tool, params)
    
    # Build return code
    return_code = _build_return_code(tool.metadata.api_type)
    
    # Indent request and return code properly 
    indented_request = '\n'.join('    ' + line for line in request_code.split('\n'))
    indented_return = '\n'.join('    ' + line for line in return_code.split('\n'))
    
    # Generate the complete function code using string template
    function_code = f'''@mcp.tool()
{signature}
    """
{docstring}
    """
{indented_request}

{indented_return}'''
    
    return function_code


def _get_function_name(tool: Tool, namespace: str) -> str:
    """Extract clean function name from tool name"""
    # Remove namespace prefix
    name = tool.name.replace(f"{namespace}_", "")

    # Convert to snake_case if needed
    # "create_benchmark_request_benchmark__post" -> "create_benchmark_request"
    # Remove HTTP method suffix patterns
    name = name.replace("_benchmark__post", "")
    name = name.replace("_benchmark__get", "")
    name = name.replace("__post", "")
    name = name.replace("__get", "")
    name = name.replace("__put", "")
    name = name.replace("__delete", "")
    name = name.replace("__patch", "")

    # Clean up double underscores
    while "__" in name:
        name = name.replace("__", "_")

    return name


def _extract_parameters(input_schema: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract parameters from JSON Schema"""
    properties = input_schema.get("properties", {})
    required = input_schema.get("required", [])

    # Filter out problematic parameters that cause 400 errors
    problematic_params = {
        "format", "markupFormat"  # These cause issues with ClinicalTrials.gov API
    }

    params = []
    for name, schema in properties.items():
        # Skip problematic parameters
        if name in problematic_params:
            continue
            
        param_type = _json_type_to_python(schema)
        
        # Use sanitized name from parser if available, otherwise sanitize here
        sanitized_name = schema.get("x-sanitized-name")
        if not sanitized_name:
            sanitized_name = _sanitize_param_name(name)
            
        params.append({
            "name": name,  # Original name for API calls (may contain dots)
            "sanitized_name": sanitized_name,  # Python-safe name
            "type": param_type,
            "required": name in required,
            "description": schema.get("description", ""),
            "schema": schema
        })

    return params


def _sanitize_param_name(name: str) -> str:
    """Sanitize parameter name to be Python-valid identifier"""
    # Replace dots, hyphens, and other invalid chars with underscores
    sanitized = name.replace(".", "_").replace("-", "_").replace(" ", "_")

    # If starts with number, prefix with underscore
    if sanitized and sanitized[0].isdigit():
        sanitized = "_" + sanitized

    # Remove any remaining non-alphanumeric chars except underscore
    sanitized = "".join(c if c.isalnum() or c == "_" else "_" for c in sanitized)

    # Python keywords handling
    python_keywords = {'and', 'as', 'assert', 'break', 'class', 'continue', 'def',
                      'del', 'elif', 'else', 'except', 'finally', 'for', 'from',
                      'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal',
                      'not', 'or', 'pass', 'raise', 'return', 'try', 'while',
                      'with', 'yield'}
    if sanitized.lower() in python_keywords:
        sanitized = sanitized + "_param"

    return sanitized


def _json_type_to_python(schema: Dict[str, Any]) -> str:
    """Convert JSON Schema type to Python type annotation"""
    json_type = schema.get("type", "string")

    # Handle arrays
    if json_type == "array":
        items_type = schema.get("items", {}).get("type", "Any")
        py_items_type = {
            "string": "str",
            "integer": "int",
            "number": "float",
            "boolean": "bool",
            "object": "dict"
        }.get(items_type, "Any")
        return f"List[{py_items_type}]"

    # Handle anyOf (optional types)
    if "anyOf" in schema:
        types = []
        has_null = False
        for any_type in schema["anyOf"]:
            if any_type.get("type") == "null":
                has_null = True
            else:
                types.append(_json_type_to_python(any_type))

        if types and has_null:
            return f"Optional[{types[0]}]"
        elif types:
            return " | ".join(types)

    # Basic types
    type_map = {
        "string": "str",
        "integer": "int",
        "number": "float",
        "boolean": "bool",
        "object": "dict",
        "array": "list"
    }

    return type_map.get(json_type, "Any")


def _build_function_signature(func_name: str, params: List[Dict[str, Any]]) -> str:
    """Build function signature with type hints"""
    if not params:
        return f"async def {func_name}() -> dict:"

    # Separate required and optional parameters
    required_params = [p for p in params if p["required"]]
    optional_params = [p for p in params if not p["required"]]
    
    # Build parameter list - required first, then optional
    param_strs = []
    
    # Add required parameters first
    for param in required_params:
        sanitized = param.get("sanitized_name", param["name"])
        param_str = f"{sanitized}: {param['type']}"
        param_strs.append(param_str)
    
    # Add optional parameters last
    for param in optional_params:
        sanitized = param.get("sanitized_name", param["name"])
        param_str = f"{sanitized}: {param['type']} = None"
        param_strs.append(param_str)

    # Format signature
    if len(param_strs) <= 2 and sum(len(p) for p in param_strs) < 60:
        # Single line
        params_str = ", ".join(param_strs)
        return f"async def {func_name}({params_str}) -> dict:"
    else:
        # Multi-line
        params_str = ",\n    ".join(param_strs)
        return f"async def {func_name}(\n    {params_str}\n) -> dict:"


def _build_docstring(tool: Tool, params: List[Dict[str, Any]]) -> str:
    """Build function docstring"""
    lines = []

    # Description
    lines.append(f"    {tool.description}")
    lines.append("")

    # Parameters
    if params:
        lines.append("    Args:")
        for param in params:
            req = " (required)" if param["required"] else " (optional)"
            desc = param["description"] or "No description"
            sanitized = param.get("sanitized_name", param["name"])
            # Show both original and sanitized if different
            if sanitized != param["name"]:
                lines.append(f"        {sanitized}: {desc}{req} (API param: {param['name']})")
            else:
                lines.append(f"        {sanitized}: {desc}{req}")
        lines.append("")

    # Returns
    lines.append("    Returns:")
    lines.append("        dict: API response")
    lines.append("")

    # Metadata
    if tool.metadata.api_type == APIType.GRAPHQL:
        lines.append(f"    GraphQL: {tool.metadata.graphql_operation.value} {tool.metadata.graphql_field}")
    else:
        lines.append(f"    OpenAPI: {tool.metadata.http_method.value} {tool.metadata.path}")

    return "\n".join(lines)


def _build_request_code(
    tool: Tool,
    params: List[Dict[str, Any]]
) -> str:
    """Build request code inside function (REST or GraphQL)"""
    
    if tool.metadata.api_type == APIType.GRAPHQL:
        return _build_graphql_request_code(tool, params)
    else:
        return _build_rest_request_code(tool, params)


def _build_rest_request_code(
    tool: Tool,
    params: List[Dict[str, Any]]
) -> str:
    """Build REST HTTP request code"""
    
    http_method = tool.metadata.http_method.value
    path = tool.metadata.path

    # Determine parameter locations
    path_params = []
    query_params = []
    body_params = []

    for param in params:
        if "{" + param["name"] + "}" in path:
            path_params.append(param)
        elif http_method == "GET":
            query_params.append(param)
        else:
            body_params.append(param)

    # Build URL
    url_code = f'url = f"{{BASE_URL}}{path}"'

    # Build request
    lines = [url_code, "async with httpx.AsyncClient(timeout=TIMEOUT) as client:"]

    # Build kwargs
    kwargs = []
    if query_params:
        query_items = []
        for p in query_params:
            sanitized = p.get("sanitized_name", p["name"])
            query_items.append(f'"{p["name"]}": {sanitized}')
        query_dict = "{" + ", ".join(query_items) + "}"
        
        # Enhanced parameter serialization to handle arrays properly
        kwargs.append(f"""params={{
            k: (','.join(map(str, v)) if isinstance(v, list) else v) 
            for k, v in {query_dict}.items() if v is not None
        }}""")

    if body_params and http_method in ["POST", "PUT", "PATCH"]:
        body_items = []
        for p in body_params:
            sanitized = p.get("sanitized_name", p["name"])
            body_items.append(f'"{p["name"]}": {sanitized}')
        body_dict = "{" + ", ".join(body_items) + "}"
        kwargs.append(f"json={{k: v for k, v in {body_dict}.items() if v is not None}}")

    # Build request line
    if kwargs:
        kwargs_str = ", ".join(kwargs)
        lines.append(f'    response = await client.{http_method.lower()}(url, {kwargs_str})')
    else:
        lines.append(f'    response = await client.{http_method.lower()}(url)')

    lines.append("    response.raise_for_status()")
    return "\n".join(lines)


def _build_graphql_request_code(
    tool: Tool,
    params: List[Dict[str, Any]]
) -> str:
    """Build GraphQL request code"""
    
    operation_type = tool.metadata.graphql_operation.value.lower()
    field_name = tool.metadata.graphql_field
    field_selection = tool.metadata.graphql_field_selection or ""
    
    lines = ["# Build GraphQL query/mutation"]
    
    # Build arguments and field selection
    if params:
        arg_items = []
        for p in params:
            sanitized = p.get("sanitized_name", p["name"])
            arg_items.append(f'"{p["name"]}": {sanitized}')
        args_dict = "{" + ", ".join(arg_items) + "}"
        
        lines.extend([
            f"args = {{k: v for k, v in {args_dict}.items() if v is not None}}",
            "",
            "# Format GraphQL arguments properly",
            "def format_value(v):",
            "    if isinstance(v, str):",
            "        return f'\\\"{v}\\\"'",
            "    elif isinstance(v, bool):",
            "        return str(v).lower()",
            "    else:",
            "        return str(v)",
            "",
            "args_str = ', '.join([f'{k}: {format_value(v)}' for k, v in args.items()])",
            "",
            "# Build query with proper field selection"
        ])
        
        # Use field selection if available, otherwise basic field
        if field_selection.strip():
            lines.extend([
                f"if args_str:",
                f'    query = "{operation_type} {{ {field_name}(" + args_str + ") {{ {field_selection} }} }}"',
                f"else:",
                f'    query = "{operation_type} {{ {field_name} {{ {field_selection} }} }}"'
            ])
        else:
            # Fallback for scalar fields (no field selection needed)
            lines.extend([
                f"if args_str:",
                f'    query = f"{operation_type} {{{{ {field_name}({{args_str}}) }}}}"',
                f"else:",
                f'    query = "{operation_type} {{{{ {field_name} }}}}"'
            ])
    else:
        # For queries/mutations without parameters
        if field_selection.strip():
            lines.append(f'query = "{operation_type} {{ {field_name} {{ {field_selection} }} }}"')
        else:
            # Fallback for scalar fields (no field selection needed) 
            lines.append(f'query = "{operation_type} {{{{ {field_name} }}}}"')
    
    lines.extend([
        "",
        "# Execute GraphQL request",
        "async with httpx.AsyncClient(timeout=TIMEOUT) as client:",
        "    response = await client.post(",
        "        BASE_URL,",
        "        json={'query': query},",
        "        headers={'Content-Type': 'application/json'}",
        "    )",
        "    response.raise_for_status()"
    ])
    
    return "\n".join(lines)


def _build_return_code(api_type: APIType) -> str:
    """Build return statement for REST or GraphQL"""
    if api_type == APIType.GRAPHQL:
        return '''result = response.json()
if "errors" in result:
    raise Exception(f"GraphQL errors: {result['errors']}")
return result.get("data", {})'''
    else:
        return '''if response.content:
    data = response.json()
    # MCP requires structured_content to be a dict or None
    # If API returns a list, wrap it in a dict
    if isinstance(data, list):
        return {"data": data, "count": len(data)}
    elif isinstance(data, dict):
        return data
    else:
        return {"result": data}
else:
    return {"success": True}'''


def _extract_used_types(tools: List[Tool]) -> set:
    """Extract all Python types used in function signatures"""
    types = set()

    for tool in tools:
        params = _extract_parameters(tool.input_schema)
        for param in params:
            param_type = param["type"]
            if "List[" in param_type:
                types.add("List")
            if "Optional[" in param_type:
                types.add("Optional")
            if "Dict[" in param_type:
                types.add("Dict")

    return types


def _generate_type_imports(used_types: set) -> str:
    """Generate typing imports based on used types"""
    if not used_types:
        return ""

    return ", " + ", ".join(sorted(used_types))
