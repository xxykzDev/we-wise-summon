"""API Type Detection - Auto-detect OpenAPI vs GraphQL endpoints"""

import httpx
import structlog
from typing import Tuple, Optional
from urllib.parse import urlparse, urljoin

from domain.entities import APIType

logger = structlog.get_logger()


class APITypeDetector:
    """Automatically detect whether a URL is OpenAPI or GraphQL"""
    
    def __init__(self, timeout: int = 15):
        self._timeout = timeout

    async def detect_api_type(self, url: str) -> Tuple[APIType, str]:
        """
        Detect API type from URL.
        
        Returns:
            Tuple of (APIType, actual_endpoint_url)
        """
        
        # Quick URL-based detection first (most reliable)
        quick_result = self._detect_from_url_pattern(url)
        if quick_result:
            return quick_result
        
        # If URL pattern is ambiguous, try HTTP-based detection
        try:
            return await self._detect_from_http_response(url)
        except Exception as e:
            logger.warning("HTTP-based detection failed, defaulting to OpenAPI", 
                          url=url, error=str(e))
            # Default to OpenAPI if detection fails
            return APIType.OPENAPI, url

    def _detect_from_url_pattern(self, url: str) -> Optional[Tuple[APIType, str]]:
        """Detect API type from URL patterns"""
        
        url_lower = url.lower()
        parsed = urlparse(url)
        path = parsed.path.lower()
        
        # Strong GraphQL indicators
        graphql_patterns = [
            '/graphql',
            '/graphql/',
            '/api/graphql',
            '/v1/graphql',
            '/v2/graphql',
            'graphql',  # Simple endpoint
        ]
        
        for pattern in graphql_patterns:
            if pattern in path:
                logger.info("Detected GraphQL from URL pattern", 
                           url=url, pattern=pattern)
                return APIType.GRAPHQL, url
        
        # Strong OpenAPI indicators 
        openapi_patterns = [
            '/openapi.json',
            '/swagger.json',
            '/api-docs',
            '/docs.json',
            '/swagger/v1/swagger.json',
            '/v1/openapi.json',
            '/v2/openapi.json',
            '/openapi.yml',
            '/swagger.yml',
        ]
        
        for pattern in openapi_patterns:
            if pattern in path:
                logger.info("Detected OpenAPI from URL pattern", 
                           url=url, pattern=pattern)
                return APIType.OPENAPI, url
        
        # No clear pattern detected
        return None

    async def _detect_from_http_response(self, url: str) -> Tuple[APIType, str]:
        """Detect API type by making HTTP requests"""
        
        # First, try GraphQL introspection query
        if await self._test_graphql_endpoint(url):
            logger.info("Detected GraphQL via introspection", url=url)
            return APIType.GRAPHQL, url
        
        # Then try common GraphQL endpoint paths
        graphql_paths = ['/graphql', '/api/graphql', '/v1/graphql']
        for path in graphql_paths:
            test_url = urljoin(url, path)
            if await self._test_graphql_endpoint(test_url):
                logger.info("Detected GraphQL via path testing", 
                           url=url, graphql_url=test_url)
                return APIType.GRAPHQL, test_url
        
        # Try fetching as OpenAPI spec
        if await self._test_openapi_spec(url):
            logger.info("Detected OpenAPI via spec validation", url=url)
            return APIType.OPENAPI, url
        
        # Try common OpenAPI paths
        openapi_paths = ['/openapi.json', '/swagger.json', '/api-docs']
        for path in openapi_paths:
            test_url = urljoin(url, path)
            if await self._test_openapi_spec(test_url):
                logger.info("Detected OpenAPI via path testing",
                           url=url, openapi_url=test_url)
                return APIType.OPENAPI, test_url
        
        # Default to OpenAPI if nothing else works
        logger.warning("Could not detect API type, defaulting to OpenAPI", url=url)
        return APIType.OPENAPI, url

    async def _test_graphql_endpoint(self, url: str) -> bool:
        """Test if URL is a GraphQL endpoint by trying introspection"""
        try:
            # Simple introspection query
            query = "query { __schema { queryType { name } } }"
            
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    url,
                    json={"query": query},
                    headers={"Content-Type": "application/json"}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    # Check for valid GraphQL response structure
                    if "data" in result and "__schema" in result.get("data", {}):
                        return True
                    # GraphQL errors are still valid GraphQL responses
                    if "errors" in result:
                        return True
                
                return False
                
        except Exception:
            return False

    async def _test_openapi_spec(self, url: str) -> bool:
        """Test if URL returns a valid OpenAPI specification"""
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.get(url)
                
                if response.status_code == 200:
                    # Try to parse as JSON
                    try:
                        content = response.json()
                    except:
                        # Try YAML parsing if JSON fails
                        import yaml
                        try:
                            content = yaml.safe_load(response.text)
                        except:
                            return False
                    
                    # Check for OpenAPI indicators
                    if isinstance(content, dict):
                        # OpenAPI 3.x
                        if "openapi" in content:
                            return True
                        # Swagger 2.x
                        if "swagger" in content:
                            return True
                        # Has paths (common indicator)
                        if "paths" in content:
                            return True
                
                return False
                
        except Exception:
            return False


# Singleton instance
api_detector = APITypeDetector()