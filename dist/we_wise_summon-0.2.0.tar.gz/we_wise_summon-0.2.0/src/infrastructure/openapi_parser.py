"""OpenAPI spec parser implementation"""

import httpx
import yaml
from typing import List, Dict, Any
import structlog

from domain.entities import Tool, ToolMetadata, OpenAPISpec, HttpMethod, APIType
from domain.exceptions import OpenAPIParseException
from application.interfaces import IOpenAPIParser


logger = structlog.get_logger()


def _sanitize_function_name(name: str) -> str:
    """Sanitize a function name to be valid Python identifier"""
    # Replace dots with underscores
    name = name.replace(".", "_")
    # Replace other invalid characters with underscores
    import re
    name = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    # Ensure it doesn't start with a number
    if name and name[0].isdigit():
        name = f"_{name}"
    return name


def _sanitize_parameter_name(name: str) -> str:
    """Sanitize a parameter name to be valid Python identifier"""
    # Python reserved keywords that need to be escaped
    reserved_keywords = {
        'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await',
        'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except',
        'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is',
        'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try',
        'while', 'with', 'yield'
    }
    
    # First sanitize like a function name
    sanitized = _sanitize_function_name(name)
    
    # If it's a reserved keyword, prefix with underscore
    if sanitized in reserved_keywords:
        sanitized = f"_{sanitized}"
    
    return sanitized


class OpenAPIParser(IOpenAPIParser):
    """Parses OpenAPI 3.x specifications and generates tools"""

    def __init__(self, timeout: int = 30):
        self._timeout = timeout

    async def discover_tools(self, url: str, namespace: str) -> List[Tool]:
        """Discover tools from OpenAPI specification (implements IOpenAPIParser)"""
        spec = await self.fetch_and_parse(url, namespace)
        return self.generate_tools(spec)

    async def fetch_and_parse(self, url: str, namespace: str) -> OpenAPISpec:
        """Fetch and parse an OpenAPI spec from a URL"""
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.get(url)
                response.raise_for_status()

                # Parse JSON or YAML
                content_type = response.headers.get("content-type", "")
                if "yaml" in content_type or url.endswith((".yaml", ".yml")):
                    content = yaml.safe_load(response.text)
                else:
                    content = response.json()

                # Validate it's an OpenAPI/Swagger spec
                if "openapi" not in content and "swagger" not in content:
                    raise OpenAPIParseException(url, "Not a valid OpenAPI/Swagger specification")

                return OpenAPISpec(url=url, namespace=namespace, content=content)

        except httpx.HTTPError as e:
            raise OpenAPIParseException(url, f"HTTP error: {str(e)}")
        except Exception as e:
            raise OpenAPIParseException(url, f"Parse error: {str(e)}")

    def generate_tools(self, spec: OpenAPISpec) -> List[Tool]:
        """Generate tools from an OpenAPI specification"""
        tools = []
        content = spec.content
        namespace = spec.namespace

        # Get base URL from servers, with fallback to spec URL
        base_url = self._extract_base_url(content, spec.url)

        # Iterate through paths
        paths = content.get("paths", {})
        for path, path_item in paths.items():
            # Iterate through HTTP methods
            for method in ["get", "post", "put", "patch", "delete"]:
                if method not in path_item:
                    continue

                operation = path_item[method]
                tool = self._create_tool_from_operation(
                    namespace=namespace,
                    path=path,
                    method=method.upper(),
                    operation=operation,
                    base_url=base_url,
                    components=content.get("components", {})
                )

                if tool:
                    tools.append(tool)

        return tools

    def _extract_base_url(self, spec: Dict[str, Any], spec_url: str) -> str:
        """Extract base URL from OpenAPI spec with fallback to spec URL"""
        servers = spec.get("servers", [])
        if servers:
            return servers[0].get("url", "")

        # Fallback: derive base URL from the spec URL
        # Handle cases like:
        # - https://petstore.swagger.io/v2/swagger.json -> https://petstore.swagger.io/v2
        # - http://host.docker.internal:8001/openapi.json -> http://host.docker.internal:8001
        if spec_url:
            from urllib.parse import urlparse
            import os
            parsed = urlparse(spec_url)
            
            # Check if URL ends with a file (has extension like .json, .yaml, .yml)
            path = parsed.path
            if path and ('.' in os.path.basename(path)):
                # Remove the filename but keep the directory path
                base_path = os.path.dirname(path) or '/'
                base_url = f"{parsed.scheme}://{parsed.netloc}{base_path}"
                # Clean up double slashes and trailing slash
                if base_url.endswith('/') and base_path == '/':
                    base_url = base_url[:-1]  # Remove trailing slash for root
            else:
                # No file extension, use the full path
                base_url = f"{parsed.scheme}://{parsed.netloc}{path}"
            
            logger.info("Using spec URL as base_url fallback",
                       spec_url=spec_url,
                       base_url=base_url)
            return base_url

        return ""

    def _create_tool_from_operation(
        self,
        namespace: str,
        path: str,
        method: str,
        operation: Dict[str, Any],
        base_url: str,
        components: Dict[str, Any]
    ) -> Tool:
        """Create a Tool from an OpenAPI operation"""

        # Generate tool name
        operation_id = operation.get("operationId")
        if operation_id:
            sanitized_operation_id = _sanitize_function_name(operation_id)
            tool_name = f"{namespace}_{sanitized_operation_id}"
        else:
            # Generate from path and method
            sanitized_path = path.replace("/", "_").replace("{", "").replace("}", "").strip("_")
            generated_name = f"{method.lower()}_{sanitized_path}"
            sanitized_name = _sanitize_function_name(generated_name)
            tool_name = f"{namespace}_{sanitized_name}"

        # Get description
        description = operation.get("summary") or operation.get("description") or f"{method} {path}"

        # Build input schema
        input_schema = self._build_input_schema(operation, components)

        # Extract request body schema if exists
        request_body_schema = None
        if "requestBody" in operation:
            request_body_schema = self._extract_request_body_schema(
                operation["requestBody"],
                components
            )

        # Create metadata
        metadata = ToolMetadata(
            api_namespace=namespace,
            api_type=APIType.OPENAPI,
            http_method=HttpMethod(method),
            path=path,
            base_url=base_url,
            operation_id=operation_id or tool_name,
            request_body_schema=request_body_schema
        )

        return Tool(
            name=tool_name,
            description=description,
            input_schema=input_schema,
            metadata=metadata
        )

    def _build_input_schema(self, operation: Dict[str, Any], components: Dict[str, Any]) -> Dict[str, Any]:
        """Build JSON Schema for tool input from operation parameters and requestBody"""
        schema = {
            "type": "object",
            "properties": {},
            "required": []
        }

        # Add parameters (path, query, header)
        parameters = operation.get("parameters", [])
        for param in parameters:
            original_name = param["name"]  # Preserve original API parameter name
            sanitized_name = _sanitize_parameter_name(original_name)  # For Python identifier
            param_in = param.get("in", "query")
            param_schema = param.get("schema", {"type": "string"})
            param_required = param.get("required", False)

            # Use original name as key, but store sanitized name for code generation
            schema["properties"][original_name] = {
                **param_schema,
                "description": param.get("description", ""),
                "x-sanitized-name": sanitized_name  # Store sanitized version for template
            }

            # Add to required if needed
            if param_required:
                schema["required"].append(original_name)

        # Add requestBody if exists
        if "requestBody" in operation:
            request_body = operation["requestBody"]
            content = request_body.get("content", {})

            # Try to get application/json schema
            json_content = content.get("application/json", {})
            body_schema = json_content.get("schema", {})

            # Resolve $ref if needed
            if "$ref" in body_schema:
                body_schema = self._resolve_ref(body_schema["$ref"], components)

            # Merge body schema properties into input schema
            if "properties" in body_schema:
                schema["properties"].update(body_schema["properties"])

            # Add required fields from body
            if "required" in body_schema:
                schema["required"].extend(body_schema["required"])

        return schema

    def _extract_request_body_schema(self, request_body: Dict[str, Any], components: Dict[str, Any]) -> Dict[str, Any]:
        """Extract request body schema"""
        content = request_body.get("content", {})
        json_content = content.get("application/json", {})
        schema = json_content.get("schema", {})

        if "$ref" in schema:
            schema = self._resolve_ref(schema["$ref"], components)

        return schema

    def _resolve_ref(self, ref: str, components: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve a $ref to its actual schema"""
        # ref format: #/components/schemas/SchemaName
        if not ref.startswith("#/components/schemas/"):
            return {}

        schema_name = ref.split("/")[-1]
        schemas = components.get("schemas", {})
        return schemas.get(schema_name, {})
