"""GraphQL Tool Source implementation - wraps GraphQL introspection parser"""

import structlog
from typing import List

from domain.entities import Tool
from application.tool_source import IToolSource
from infrastructure.graphql_parser import GraphQLIntrospectionParser

logger = structlog.get_logger()


class GraphQLToolSource(IToolSource):
    """Tool source that parses GraphQL schemas via introspection"""

    def __init__(self, endpoint_url: str, namespace: str):
        """
        Initialize GraphQL tool source.

        Args:
            endpoint_url: URL to GraphQL endpoint 
            namespace: Namespace prefix for tools from this source
        """
        self._endpoint_url = endpoint_url
        self._namespace = namespace
        self._parser = GraphQLIntrospectionParser(timeout=30)
        self._tools_count: int = 0

    async def discover_tools(self) -> List[Tool]:
        """Discover tools from GraphQL endpoint"""
        logger.info("Discovering tools from GraphQL endpoint",
                   url=self._endpoint_url,
                   namespace=self._namespace)

        try:
            # Perform introspection and parse the schema
            spec = await self._parser.fetch_and_parse(self._endpoint_url, self._namespace)

            # Generate tools
            tools = self._parser.generate_tools(spec)

            logger.info("Discovered GraphQL tools",
                       namespace=self._namespace,
                       tool_count=len(tools))

            self._tools_count = len(tools)
            return tools

        except Exception as e:
            logger.error("Failed to discover GraphQL tools",
                        url=self._endpoint_url,
                        namespace=self._namespace,
                        error=str(e),
                        exc_info=True)
            # Don't raise - return empty list so other sources can still work
            return []

    def get_source_info(self) -> dict:
        """Get information about this GraphQL source"""
        return {
            "type": "graphql",
            "url": self._endpoint_url,
            "namespace": self._namespace,
            "tools_count": self._tools_count
        }