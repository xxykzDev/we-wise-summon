"""
Minimal configuration for MCP server generation
"""

class Settings:
    """MCP server generation settings"""
    
    # Docker Compose ports
    mcp_base_port = 8500
    mcp_default_port = 9000
    
    # Output directory for generated files
    mcp_output_dir = "mcp_output"

# Global settings instance
settings = Settings()