# 🧙‍♂️ We-Wise SUMMON - Unified CLI + Advanced MCP Generator

> **UNIFIED REPOSITORY**: Combining CLI management with production-grade API parsing and MCP server generation

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CLI Tool](https://img.shields.io/badge/tool-CLI-green.svg)]()
[![Real API Parsing](https://img.shields.io/badge/parsing-OpenAPI%2FGraphQL-orange.svg)]()

**UNIFIED SUCCESS**: This repository successfully combines a CLI tool with an advanced MCP generator that creates **real** MCP servers with actual HTTP/GraphQL calls. No placeholders - real tools from real API specifications.

✨ **Achievement**: Generated 73+ real tools from httpbin OpenAPI spec with working HTTP calls

## 🎯 What Does SUMMON Do?

```
API Specification  →  SUMMON CLI  →  Production MCP Server
     ↓                     ↓                   ↓
   REST/GraphQL       Intelligent         FastMCP-based
   OpenAPI Spec       Auto-Detection      Server Files
```

**Transform APIs into MCP servers in seconds:**

- ✅ **Auto-Detection**: Automatically detects REST vs GraphQL APIs
- ✅ **Intelligent Parsing**: OpenAPI specs + GraphQL introspection  
- ✅ **Type-Safe Generation**: Full Python type hints and validation
- ✅ **Dual-Mode Servers**: stdio (Claude Desktop) + HTTP (agent frameworks)
- ✅ **Production Ready**: Error handling, timeouts, parameter sanitization
- ✅ **Zero Configuration**: Works out of the box with sensible defaults

## 🚀 Quick Start

### Installation

```bash
# Install from source (recommended for development)
git clone https://github.com/we-wise/summon
cd we-wise-summon
python3 -m venv venv
source venv/bin/activate
pip install -e .
```

### Basic Usage

```bash
# Initialize a new project
summon init my-api-project
cd my-api-project

# Add APIs (auto-detects REST vs GraphQL)
summon add https://api.github.com/graphql --name github
summon add https://jsonplaceholder.typicode.com/ --name jsonplaceholder

# List configured APIs
summon list

# Generate MCP servers
summon generate

# Your MCP servers are ready!
ls mcps/
# → mcp_server_github.py
# → mcp_server_jsonplaceholder.py
```

### Test Generated Servers

```bash
# Test in stdio mode (Claude Desktop)
python mcps/mcp_server_github.py

# Test in HTTP mode (agent frameworks)  
python mcps/mcp_server_github.py --http 8500
```

## 🛠️ CLI Commands

### Project Management

```bash
summon init <project-name>    # Initialize new project
summon add <api-url>          # Add API to project  
summon list                   # List configured APIs
summon generate              # Generate MCP servers
```

### Options & Flags

```bash
# Custom API names
summon add https://api.example.com --name myapi

# Custom output directory
summon generate --output ./servers

# Help and version
summon --help
summon --version
```

## 📂 Project Structure

```
my-api-project/
├── .summon/
│   └── config.json          # Project configuration
├── mcps/                    # Generated MCP servers
│   ├── mcp_server_github.py
│   └── mcp_server_jsonplaceholder.py
└── .gitignore              # Excludes generated files
```

### Configuration File (`.summon/config.json`)

```json
{
  "project_name": "my-api-project",
  "version": "0.1.0",
  "output_dir": "./mcps",
  "apis": [
    {
      "name": "github",
      "url": "https://api.github.com/graphql",
      "type": "GRAPHQL",
      "added_at": "/path/to/project"
    },
    {
      "name": "jsonplaceholder", 
      "url": "https://jsonplaceholder.typicode.com/",
      "type": "REST",
      "added_at": "/path/to/project"
    }
  ]
}
```

## 🔧 Generated MCP Servers

### Server Capabilities

Each generated server includes:

- **FastMCP Framework**: Modern, minimal boilerplate MCP server
- **Dual Execution Modes**: 
  - `stdio` for Claude Desktop integration
  - `--http <port>` for multi-agent frameworks
- **Type Safety**: Full Python type hints and validation
- **Error Handling**: Robust error handling with meaningful messages
- **Parameter Sanitization**: Automatic handling of invalid Python identifiers
- **Documentation**: Auto-generated docstrings with API context

### Example Generated Server

```python
#!/usr/bin/env python3
"""
MCP Server for github
Auto-generated from GRAPHQL API using We-Wise SUMMON
"""

from fastmcp import FastMCP

mcp = FastMCP("github")

@mcp.tool()
async def get_repository_info(owner: str, name: str) -> dict:
    """
    Get repository information from GitHub GraphQL API
    
    Args:
        owner: Repository owner username
        name: Repository name
        
    Returns:
        dict: Repository data
    """
    # Auto-generated GraphQL query with proper field selection
    query = '''
    query GetRepository($owner: String!, $name: String!) {
        repository(owner: $owner, name: $name) {
            name
            description
            stargazerCount
            forkCount
        }
    }
    '''
    # HTTP client implementation with error handling
    # ... rest of implementation

if __name__ == "__main__":
    mcp.run()
```

### Usage Modes

```bash
# Claude Desktop (stdio mode)
python mcp_server_github.py

# Multi-agent frameworks (HTTP mode)
python mcp_server_github.py --http 8500

# With custom configuration
export GITHUB_API_TOKEN=your_token
python mcp_server_github.py --http 8500
```

## 🔌 Integration Examples

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "github": {
      "command": "python",
      "args": ["/path/to/mcps/mcp_server_github.py"]
    },
    "jsonplaceholder": {
      "command": "python", 
      "args": ["/path/to/mcps/mcp_server_jsonplaceholder.py"]
    }
  }
}
```

### Multi-Agent Frameworks

```python
# Example integration with agent framework
from mcp.client.stdio import stdio_client

async with stdio_client("python", "mcps/mcp_server_github.py") as streams:
    async with ClientSession(streams[0], streams[1]) as session:
        # List available tools
        tools = await session.list_tools()
        
        # Call a tool
        result = await session.call_tool(
            "get_repository_info", 
            {"owner": "octocat", "name": "Hello-World"}
        )
```

## 🎓 Advanced Features

### API Type Auto-Detection

SUMMON automatically detects API types:

```bash
# GraphQL APIs (detects /graphql, schema queries)
summon add https://api.github.com/graphql
# → Detected: GRAPHQL

# REST APIs (detects OpenAPI specs, REST patterns)  
summon add https://jsonplaceholder.typicode.com/
# → Detected: REST
```

### Custom Server Configuration

Generated servers support environment-based configuration:

```bash
# API credentials
export GITHUB_API_TOKEN=your_token
export API_BASE_URL=https://custom.api.endpoint

# Request settings
export TIMEOUT=30.0
export RETRY_ATTEMPTS=3

# Run server with custom config
python mcp_server_github.py --http 8500
```

### Parameter Sanitization

SUMMON automatically handles invalid Python identifiers:

```yaml
# OpenAPI Parameter: "query.filter" 
# Generated Python: query_filter
# API Call: Maps back to "query.filter"

# This just works:
@mcp.tool()
async def search_items(query_filter: str, sort_by: str = None) -> dict:
    # API call uses original parameter names
    response = await client.get(url, params={
        "query.filter": query_filter,  # ✅ Original name preserved
        "sort-by": sort_by
    })
```

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│               SUMMON CLI                    │
│                                             │
│ ┌─────────────┐    ┌─────────────────────┐ │
│ │   Auto      │    │    Code Generator   │ │
│ │ Detection   │───▶│   (FastMCP based)   │ │
│ │             │    │                     │ │
│ └─────────────┘    └─────────────────────┘ │
│       │                       │            │
│       ▼                       ▼            │
│ ┌─────────────┐    ┌─────────────────────┐ │
│ │  OpenAPI    │    │     Generated       │ │
│ │  GraphQL    │    │   MCP Servers       │ │
│ │  Parsers    │    │                     │ │
│ └─────────────┘    └─────────────────────┘ │
└─────────────────────────────────────────────┘
                            │
                            ▼
              ┌──────────────────────────┐
              │     Generated Servers    │
              │     (FastMCP Runtime)    │
              │                          │
              │  ┌────────────────────┐  │
              │  │  • Auto-Detection  │  │
              │  │  • Type Safety     │  │
              │  │  • Error Handling  │  │
              │  │  • Dual Mode       │  │
              │  └────────────────────┘  │
              └──────────────────────────┘
                      │            │
                      ▼            ▼
              ┌────────────┐  ┌──────────┐
              │   Claude   │  │  Agent   │
              │  Desktop   │  │Framework │
              │  (stdio)   │  │  (HTTP)  │
              └────────────┘  └──────────┘
```

## 📋 Development Roadmap

### ✅ **Current (v0.2.0) - UNIFIED ACHIEVEMENT**
- [x] **Complete CLI + Advanced Generator Integration**
  - [x] Unified repository structure with both CLI and advanced generator  
  - [x] Real OpenAPI parsing (Swagger 2.0 + OpenAPI 3.x) with operation extraction
  - [x] Real GraphQL introspection with query/mutation generation
  - [x] Type-safe parameter mapping and validation
  - [x] Production-ready MCP servers with actual HTTP/GraphQL calls
- [x] **CLI Interface with Project Management** 
  - [x] Project initialization, API addition, generation workflow
  - [x] Auto-detection of API types (OpenAPI vs GraphQL)
  - [x] Configuration management and project structure
- [x] **Real API Parsing Results**
  - [x] ✅ 73+ tools generated from httpbin OpenAPI spec  
  - [x] ✅ Working HTTP calls with httpx async client
  - [x] ✅ FastMCP-based servers with dual stdio/HTTP modes

### 🚧 **Next (v0.3.0)**
- [ ] **Enhanced Features**
  - [ ] Web dashboard for project management
  - [ ] Enhanced GraphQL subscriptions support
  - [ ] Custom authentication flow integration

### 🔮 **Future (v0.4.0+)**
- [ ] Docker deployment automation
- [ ] Plugin system for custom parsers
- [ ] Multi-language server generation (Go, TypeScript)
- [ ] Authentication flow templates

## 🔧 Development Setup

### Prerequisites
- Python 3.8+
- Git

### Local Development

```bash
# Clone repository
git clone https://github.com/we-wise/summon
cd we-wise-summon

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Install CLI in development mode
pip install -e .

# Verify installation
summon --help
```

### Testing

```bash
# Run basic functionality tests
python test_cli.py

# Manual testing with sample APIs
python manual_test.py

# Test CLI workflow
summon init test-project
cd test-project
summon add https://jsonplaceholder.typicode.com/ --name test
summon generate
python mcps/mcp_server_test.py
```

## 🤝 Contributing

We welcome contributions! Here's how to get started:

### Development Workflow

```bash
# 1. Fork and clone
git clone https://github.com/yourusername/summon
cd summon

# 2. Create feature branch
git checkout -b feature/your-feature

# 3. Make changes and test
pip install -e .
summon --help

# 4. Commit and push
git add .
git commit -m "Add your feature"
git push origin feature/your-feature

# 5. Create pull request
```

### Code Style

- **Python**: Follow PEP 8, use type hints
- **CLI**: Consistent command naming and help text
- **Documentation**: Update README for new features
- **Tests**: Add tests for new functionality

## 📚 Additional Resources

### MCP Protocol
- [Model Context Protocol Specification](https://modelcontextprotocol.io)
- [FastMCP Framework](https://github.com/jlowin/fastmcp) 
- [MCP Client Libraries](https://github.com/modelcontextprotocol)

### API Specifications
- [OpenAPI Specification](https://swagger.io/specification/)
- [GraphQL Specification](https://graphql.org/learn/)
- [GraphQL Introspection](https://graphql.org/learn/introspection/)

### Related Tools
- [Claude Desktop](https://claude.ai/desktop) - AI assistant with MCP support
- [LangChain](https://langchain.com) - Multi-agent framework with MCP integration
- [Anthropic Tools](https://docs.anthropic.com/claude/docs/tool-use) - AI tool usage patterns

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🙋‍♀️ Support

- **Issues**: [GitHub Issues](https://github.com/we-wise/summon/issues)
- **Discussions**: [GitHub Discussions](https://github.com/we-wise/summon/discussions)
- **Email**: contact@we-wise.ai

---

**Built with ❤️ by [We-Wise](https://we-wise.ai) - Making APIs accessible to AI agents**